' DailyRefresh.vbs - double-click (or pin to the taskbar) to run the whole morning refresh.
' SAP GUI must be open and logged on. Everything else happens by itself.
Const DB_PATH = "C:\Reports\SAP_Runner.accdb"   ' <-- the Access file you imported DailyRefresh.bas into

Dim acc
Set acc = CreateObject("Access.Application")
acc.Visible = True
acc.OpenCurrentDatabase DB_PATH
acc.Run "RunDailyRefresh"   ' or "RunDailyRefreshWithP3381" to chain a second feed (Phase 2b)
acc.CloseCurrentDatabase
acc.Quit
Set acc = Nothing
