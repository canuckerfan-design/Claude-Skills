# fabric_io_python_delta.py - template for a Fabric PYTHON (non-Spark) notebook cell.
# Paste into the notebook BEFORE the ingest code. Requires a TABLES contract defined
# earlier in the notebook (or imported), e.g.:
#   TABLES = {"fact_stock": [("Material", "string"), ("Date", "date"), ("Quantity", "double")], ...}
#   types: string | int64 | double | date | timestamp | bool
# `notebookutils` is the Fabric built-in (no import needed in a Fabric notebook).
# Example names (lh_p3381_daily) come from the P3381 project - change the error text for your lakehouse.
# ---- Fabric I/O: Delta tables in the attached (default) lakehouse ----------
# Writes go to OneLake over abfss with a notebook token, not through the
# /lakehouse/default FUSE mount: Delta commits rename files, and the mount
# refuses the rename ("Unable to rename file", 02/10/2026). Schema-enabled
# lakehouses (Tables/dbo) are detected and written to dbo.
import datetime as dt, json, os, random, time
from zoneinfo import ZoneInfo
import pandas as pd
import pyarrow as pa
from deltalake import DeltaTable, write_deltalake

TABLES_URI = ""        # optional override, e.g. abfss://<ws-id>@onelake.dfs.fabric.microsoft.com/<lh-id>/Tables/dbo
_PA = {"string": pa.string(), "int64": pa.int64(), "double": pa.float64(), "date": pa.date32(),
       "timestamp": pa.timestamp("us", tz="UTC"), "bool": pa.bool_()}


def _tables_uri() -> str:
    if TABLES_URI:
        return TABLES_URI.rstrip("/")
    ctx = notebookutils.runtime.context
    ws, lh = ctx.get("currentWorkspaceId"), ctx.get("defaultLakehouseId")
    if not ws or not lh:
        raise RuntimeError("No default lakehouse attached to the notebook - add lh_p3381_daily as the default "
                           "lakehouse (Explorer > Lakehouses), or set TABLES_URI.")
    base = f"abfss://{ws}@onelake.dfs.fabric.microsoft.com/{lh}/Tables"
    return base + "/dbo" if os.path.isdir("/lakehouse/default/Tables/dbo") else base


def _storage() -> dict:
    return {"bearer_token": notebookutils.credentials.getToken("storage"), "use_fabric_endpoint": "true"}


def _is_null(v) -> bool:
    return v is None or v is pd.NaT or (isinstance(v, float) and v != v)


def _cast(v, ty):
    if _is_null(v):
        return None
    if ty == "string":
        return str(v)
    if ty == "int64":
        return int(v)
    if ty == "double":
        return float(v)
    if ty == "bool":
        return bool(v)
    if ty == "date":
        return pd.Timestamp(v).date()
    if ty == "timestamp":
        # UK wall-clock time stored with a UTC label, so the SQL endpoint and
        # Power BI show 16:54 rather than shifting it by the BST offset.
        t = pd.Timestamp(v)
        t = t.tz_localize(None) if t.tzinfo is not None else t
        return t.tz_localize("UTC").to_pydatetime()
    raise ValueError(ty)


COMMIT_RETRIES = 6                                    # a second run writing the same table at the same moment


def _is_conflict(e: Exception) -> bool:
    m = (type(e).__name__ + " " + str(e)).lower()
    return any(k in m for k in ("commitfailed", "concurrent", "conflict", "version already exists", "transaction"))


def write_table(name: str, df: pd.DataFrame) -> None:
    cols = TABLES[name]                              # fixed contract - an empty batch never changes a type
    arrays = {c: pa.array([_cast(v, ty) for v in df[c].tolist()], type=_PA[ty]) for c, ty in cols}
    data = pa.table(arrays)
    for attempt in range(1, COMMIT_RETRIES + 1):
        try:
            write_deltalake(f"{_tables_uri()}/{name}", data, mode="overwrite", schema_mode="overwrite",
                            storage_options=_storage())
            return
        except Exception as e:                       # overwrite is idempotent - just try again
            if not _is_conflict(e) or attempt == COMMIT_RETRIES:
                raise
            wait = 3 * attempt + random.uniform(0, 3)
            print(f"  {name}: another run committed at the same time - retry {attempt} in {wait:.0f}s")
            time.sleep(wait)


def read_table(name: str):
    try:
        return DeltaTable(f"{_tables_uri()}/{name}", storage_options=_storage()).to_pandas()
    except Exception as e:                           # first run: the table does not exist yet
        msg = (type(e).__name__ + " " + str(e)).lower()
        if any(k in msg for k in ("not a delta table", "no files in log segment", "no log files",
                                  "tablenotfound", "not found", "does not exist")):
            return None
        raise
