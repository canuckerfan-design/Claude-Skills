Attribute VB_Name = "DailyRefresh"
Option Explicit

' ============================================================================
'   DailyRefresh - Bradford SAP -> Fabric Lakehouse feed (ONE module)
'   v2.3 - 2026-10-02  New button RunDailyRefreshWithP3381: the daily refresh exactly as
'                       before, then it WAITS until the Bradford batch file is in
'                       Bradford_BI_LH (so those pipelines / reports start first), then
'                       runs the P3381 dashboard feed (MB52, ZMELPA03_KIB, COOIS,
'                       ZSDU106897, MB51 -> lh_p3381_daily) with the values fixed below,
'                       and ends with one status dialog for both. RunP3381Feed runs the
'                       P3381 part on its own. RunDailyRefresh itself is unchanged.
'   v2.2 - 2026-10-01  KE24: when SAP returns no line items (current period on the 1st of
'                       the month) the job stops cleanly instead of pressing Export on the
'                       selection screen ("Choose a valid function"). Waits for SAP after save.
'   v2.1 - 2026-09-24  Batch file written as plain text (no UTF-8 marker) so Fabric reads
'                       the first file name correctly.
'   v2.0 - 2026-09-24  All SAP exports (inventory, MB52, KE24) are sent to the lakehouse
'                       exactly as SAP wrote them; the notebook nb_daily_ingest converts
'                       them. No file conversion left in Access for SAP data.
'   (v1.1 - v1.8: one SAP session, busy-waits, background upload, first-run-of-month
'    KE24 close, FG stock built in Fabric.)
'
'   Replaces ALL of these (delete them after importing this one):
'     Inventory DB : mod_Main_Controller, mod_SAP_Export, mod_Data_Ingest,
'                    mod_ErrorLog, BackfillDailySnapshot, ImportProvisions
'     Sales DB     : mod_FormActions, mod_KE24_Extract, mod_FGStock_Extract,
'                    mod_Helpers, mod_ImportForecast, mod_RawDump
'
'   What it does
'     SAP (your recorded script steps, unchanged) -> raw SAP export file ->
'     Lakehouse landing folder (through OneLake File Explorer, in the
'     background) -> one "_ready" batch file.  The batch file fires the
'     Fabric pipeline, which loads the Delta tables and refreshes all three
'     Power BI reports.  No Access tables are used any more - the business
'     rules (customer mapping, finance sections, month-end freeze, material
'     master) run in the Fabric notebook nb_daily_ingest.
'
'   Entry points (run from an Access macro: RunCode  RunDailyRefresh() etc.)
'     RunDailyRefreshWithP3381 - daily refresh, wait for its upload, then the
'                            P3381 dashboard feed; one status dialog at the end
'     RunDailyRefresh      - THE daily button: inventory snapshot, MB52,
'                            KE24 (+ month-end close when due). FG stock is
'                            built from the inventory snapshot in Fabric
'     RunP3381Feed         - the P3381 dashboard feed on its own
'     RunInventoryMonthEnd - S_P99 for a period range -> tbl_InventoryHistory
'     RunKE24Backfill      - re-extract N closed months of KE24
'     RunForecastImport    - Finance / DCC forecast workbook -> tbl_Forecast
'     RunProvisionImport   - Finance E&O provision workbooks -> tbl_Provision
'     RunSnapshotBackfill  - Excel file -> tbl_DailySnapshot for one date
'   Run any of these from an Access macro (RunCode, e.g. RunProvisionImport())
'
'   Works in Access or Excel (late bound, no references needed).
'   Log files: C:\Temp\SAPExports\DailyRefresh_log.txt  (steps + seconds per step)
'              C:\Temp\SAPExports\Upload_log.txt        (background OneLake upload:
'                                                         one line per batch; per-file
'                                                         detail in uploadlogs\)
' ============================================================================

#If VBA7 Then
Private Declare PtrSafe Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Private Declare PtrSafe Function OpenClipboard Lib "user32" (ByVal hwnd As LongPtr) As Long
Private Declare PtrSafe Function EmptyClipboard Lib "user32" () As Long
Private Declare PtrSafe Function CloseClipboard Lib "user32" () As Long
Private Declare PtrSafe Function SetClipboardData Lib "user32" (ByVal uFormat As Long, ByVal hData As LongPtr) As LongPtr
Private Declare PtrSafe Function GlobalAlloc Lib "kernel32" (ByVal uFlags As Long, ByVal dwBytes As LongPtr) As LongPtr
Private Declare PtrSafe Function GlobalLock Lib "kernel32" (ByVal hMem As LongPtr) As LongPtr
Private Declare PtrSafe Function GlobalUnlock Lib "kernel32" (ByVal hMem As LongPtr) As Long
Private Declare PtrSafe Function lstrcpyW Lib "kernel32" (ByVal lpDst As LongPtr, ByVal lpSrc As LongPtr) As LongPtr
#Else
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Private Declare Function OpenClipboard Lib "user32" (ByVal hwnd As Long) As Long
Private Declare Function EmptyClipboard Lib "user32" () As Long
Private Declare Function CloseClipboard Lib "user32" () As Long
Private Declare Function SetClipboardData Lib "user32" (ByVal uFormat As Long, ByVal hData As Long) As Long
Private Declare Function GlobalAlloc Lib "kernel32" (ByVal uFlags As Long, ByVal dwBytes As Long) As Long
Private Declare Function GlobalLock Lib "kernel32" (ByVal hMem As Long) As Long
Private Declare Function GlobalUnlock Lib "kernel32" (ByVal hMem As Long) As Long
Private Declare Function lstrcpyW Lib "kernel32" (ByVal lpDst As Long, ByVal lpSrc As Long) As Long
#End If
Private Const CF_UNICODETEXT As Long = 13
Private Const GMEM_MOVEABLE_ZEROINIT As Long = &H42

' --- Settings (the only lines you should ever need to change) --------------
Private Const FABRIC_WORKSPACE  As String = "Bradford BI Analytics"
Private Const FABRIC_LAKEHOUSE  As String = "Bradford_BI_LH"
Private Const SAP_EXPORT_DIR    As String = "C:\Temp\SAPExports\"
Private Const LOG_FILE_NAME     As String = "DailyRefresh_log.txt"

' --- SAP selections (from your recordings) ---------------------------------
Private Const INV_TCODE         As String = "S_P99_41000062"
Private Const INV_VARIANT       As String = "/BFDINV"
Private Const MB52_TCODE        As String = "MB52"
Private Const MB52_PLANT        As String = "6000"
Private Const MB52_VARIANT      As String = "/BFD_LOCATIO"
Private Const KE24_TCODE        As String = "KE24"
Private Const KE24_OP_CONCERN   As String = "0020"
Private Const KE24_VARIANT_USER As String = "AKANNENKERIL"

Private Const FILE_WAIT_SECS    As Long = 120
Private Const SAP_BUSY_SECS     As Long = 300     ' max wait for SAP to finish one step
Private Const UPLOAD_LOG_NAME   As String = "Upload_log.txt"
Private Const PIPE              As String = "|"
Private Const DAILY_UPLOAD_WAIT_SECS As Long = 660 ' wait for the Bradford batch file before P3381
                                                   ' (the background upload gives up at ~10 min)

' --- P3381 dashboard feed - fixed values (Feed / Scope sheets of the Excel feed, 02/10/2026) ---
Private Const P3_LAKEHOUSE      As String = "lh_p3381_daily"               ' same workspace as above
Private Const P3_EXPORT_DIR     As String = "C:\Temp\SAPExports\P3381Feed\"
Private Const P3_PLANT          As String = "6000"
Private Const P3_SLOC           As String = "6000"     ' MB52 storage location
Private Const P3_VKORG          As String = "6000"     ' ZSDU106897 sales organisation
Private Const P3_HORIZON_DAYS   As Long = 30           ' ZMELPA03_KIB, calendar days
Private Const P3_SHIP_DAYS      As Long = 14           ' MB51 look-back, calendar days (output + shipments)
Private Const P3_MB51_SLOC      As String = "6000"     ' MB51 storage location ("" = all)
Private Const P3_DAY_BASIS      As String = "Shifts"   ' Shifts | Posting date
Private Const P3_MB52_VARIANT   As String = "/BFD_LOCATIO"
Private Const P3_COOIS_VARIANT  As String = "/7400_ORDERS"
Private Const P3_ZSDU_VARID     As String = "WEEKLY_REC"
Private Const P3_MB51_VARIANT   As String = "/with ref"
Private Const P3_KEEP_LOCAL     As Boolean = False     ' keep the local SAP files (N)
Private Const P3_EXPORT_WAIT_SEC As Long = 90
Private Const P3_PREFIX         As String = "p3381"
Private Const P3_FEED_VERSION   As String = "1.1-access"
Private Const P3_MB51_MVTS      As String = "101,102,601,602"   ' recorded in run_info - the notebook checks it

' --- Module-level state ------------------------------------------------------
Private m_batch As Collection        ' "feed/file.csv|bytes" dropped this run
Private m_fso As Object
Private m_sess As Object             ' one SAP session reused by every job in a run
Private m_sessOwned As Boolean       ' True = we opened it (/o), so we close it (/i)
Private m_mark As Double             ' Timer value at the end of the previous job
Private m_seq As Long                ' makes feed file names unique within a run
Private m_lastBatchFile As String    ' batch file of the last FinishBatch ("" = nothing sent)
Private m_lastItems As Collection    ' feed files of that batch (to report upload progress)
Private m_p3Status As Object         ' P3381: source -> Array(status, at, file, message)
Private m_p3Stamp As String          ' P3381 batch id yyyymmdd_hhnnss
Private m_p3RunAt As Date

' ============================================================================
'   PUBLIC ENTRY POINTS
' ============================================================================

' Daily refresh, then (once its batch file is in Bradford_BI_LH) the P3381 dashboard feed.
Public Function RunDailyRefreshWithP3381() As Boolean
    Dim t0 As Date, daily As String, nOk As Long, nFail As Long, upMsg As String, upOk As Boolean
    Dim p3 As String, p3Ok As Long, p3Fail As Long, msg As String, allOk As Boolean
    t0 = Now
    LogMsg "=== Daily refresh + P3381 feed started ==="

    ' 1. Bradford daily refresh - same jobs, same uploads; its dialog is held back
    If Not DailyRefreshCore(daily, nOk, nFail, False) Then Exit Function    ' message already shown

    ' 2. Bradford files must be in the lakehouse before the P3381 SAP steps start
    upOk = WaitForDailyUpload(m_lastBatchFile, DAILY_UPLOAD_WAIT_SECS, upMsg)

    ' 3. P3381 dashboard feed
    p3 = P3_RunFeed(p3Ok, p3Fail)
    ShowStatus ""

    ' 4. one status dialog for both
    allOk = (nFail = 0 And upOk And p3Fail = 0)
    msg = "BRADFORD DAILY REFRESH  ->  " & FABRIC_LAKEHOUSE & vbCrLf & daily & upMsg & vbCrLf & vbCrLf & _
          "P3381 DASHBOARD  ->  " & P3_LAKEHOUSE & vbCrLf & p3 & vbCrLf & _
          "Total time " & Format$(Now - t0, "nn:ss") & ". Keep the PC on and signed in for 10 minutes."
    LogMsg "Daily refresh + P3381 finished. " & IIf(allOk, "All OK", "With problems") & vbCrLf & msg
    If Len(msg) > 1000 Then msg = Left$(msg, 960) & vbCrLf & "... (full detail in " & LOG_FILE_NAME & ")"
    MsgBox msg, IIf(allOk, vbInformation, vbExclamation), _
           "Daily refresh + P3381 - " & IIf(allOk, "all done", "check the FAILED lines")
    RunDailyRefreshWithP3381 = allOk
End Function

' The P3381 dashboard feed on its own (no Bradford refresh).
Public Function RunP3381Feed() As Boolean
    Dim t0 As Date, p3 As String, p3Ok As Long, p3Fail As Long
    t0 = Now
    If Not Fso.FolderExists(SAP_EXPORT_DIR) Then CreateFolderPath SAP_EXPORT_DIR
    p3 = P3_RunFeed(p3Ok, p3Fail)
    ShowStatus ""
    MsgBox "P3381 DASHBOARD  ->  " & P3_LAKEHOUSE & vbCrLf & p3 & vbCrLf & "Elapsed " & Format$(Now - t0, "nn:ss"), _
           IIf(p3Fail = 0, vbInformation, vbExclamation), "P3381 feed"
    RunP3381Feed = (p3Fail = 0)
End Function

Public Function RunDailyRefresh() As Boolean
    Dim summary As String, nOk As Long, nFail As Long
    If Not DailyRefreshCore(summary, nOk, nFail, True) Then Exit Function
    RunDailyRefresh = (nFail = 0)
End Function

' The daily refresh body (unchanged). Returns False only if the batch could not start.
' summary comes back with the job lines (without the upload notes FinishBatch adds).
Private Function DailyRefreshCore(ByRef summary As String, ByRef nOk As Long, ByRef nFail As Long, _
                                  ByVal showDialog As Boolean) As Boolean
    Dim t0 As Date
    Dim firstRunOfMonth As Boolean, tSap As Double
    Dim rInv As String, rMB52 As String, rME As String, rCur As String
    Dim prevP As String, prevY As String, curP As String, curY As String
    t0 = Now
    If Not StartBatch() Then Exit Function
    LogMsg "=== Daily refresh started ==="
    ' KE24 month-end close only on the first daily run of a new month (local marker file)
    firstRunOfMonth = (LastCloseMonth() <> Format$(Date, "yyyymm"))
    prevP = Format$(Month(DateAdd("m", -1, Date)), "000"): prevY = CStr(Year(DateAdd("m", -1, Date)))
    curP = Format$(Month(Date), "000"): curY = CStr(Year(Date))

    ' 1. All SAP extracts back to back - files are processed afterwards
    tSap = Timer
    rInv = JobInventory("", "", "", True)
    rMB52 = JobMB52(True)
    If firstRunOfMonth Then rME = JobKE24(prevP, prevY, "MonthEnd", True) _
                       Else rME = "NOT NEEDED - already closed on the first run this month"
    rCur = JobKE24(curP, curY, "Current", True)
    EndSAP
    LogMsg "All SAP extracts done in " & Format$(SecondsSince(tSap), "0") & "s"
    summary = "SAP extracts: " & Format$(SecondsSince(tSap), "0") & "s" & vbCrLf

    ' 2. Read, convert and queue the uploads
    m_mark = Timer
    summary = summary & JobLine("Inventory snapshot (S_P99)", FinishQueued(rInv, "inv", "", "", ""), nOk, nFail)
    summary = summary & JobLine("MB52 storage areas", FinishQueued(rMB52, "mb52", "", "", ""), nOk, nFail)
    rME = FinishQueued(rME, "ke24", prevP, prevY, "MonthEnd")
    If firstRunOfMonth And Left$(rME, 2) = "OK" Then SaveCloseMonth Format$(Date, "yyyymm")
    summary = summary & JobLine("KE24 month-end close", rME, nOk, nFail)
    summary = summary & JobLine("KE24 current month", FinishQueued(rCur, "ke24", curP, curY, "Current"), nOk, nFail)

    FinishBatch summary, nOk, nFail, t0, "Daily refresh", showDialog
    DailyRefreshCore = True
End Function

' A deferred job returns "QUEUED|<sap file>": process that file now. Anything else passes through.
Private Function FinishQueued(ByVal result As String, ByVal kind As String, ByVal sPeriod As String, _
                              ByVal sYear As String, ByVal runKind As String) As String
    Dim sapFile As String
    If Left$(result, 7) <> "QUEUED|" Then FinishQueued = result: Exit Function
    sapFile = Mid$(result, 8)
    Select Case kind
        Case "inv":  FinishQueued = ProcessInventory(sapFile, sPeriod, sYear)
        Case "mb52": FinishQueued = ProcessMB52(sapFile)
        Case "ke24": FinishQueued = ProcessKE24(sapFile, sPeriod, sYear, runKind)
    End Select
End Function

Public Function RunInventoryMonthEnd() As Boolean
    Dim sFrom As String, sTo As String, sParts As String
    Dim fromP As Long, fromY As Long, toP As Long, toY As Long
    Dim p As Long, y As Long, summary As String, nOk As Long, nFail As Long, t0 As Date

    sFrom = InputBox("From period (MM/YYYY):", "Inventory month-end", Format$(DateAdd("m", -1, Date), "mm/yyyy"))
    If Len(Trim$(sFrom)) = 0 Then Exit Function
    sTo = InputBox("To period (MM/YYYY):", "Inventory month-end", sFrom)
    If Len(Trim$(sTo)) = 0 Then Exit Function
    If Not ParsePeriod(sFrom, fromP, fromY) Or Not ParsePeriod(sTo, toP, toY) Then
        MsgBox "Periods must be MM/YYYY, e.g. 08/2026.", vbExclamation: Exit Function
    End If
    If (toY * 100 + toP) < (fromY * 100 + fromP) Then
        MsgBox "'To' must be on or after 'From'.", vbExclamation: Exit Function
    End If
    sParts = InputBox("Optional: part numbers to limit the extract (separate with commas)." & vbCrLf & _
                      "Leave blank for all materials.", "Inventory month-end", "")

    t0 = Now
    If Not StartBatch() Then Exit Function
    p = fromP: y = fromY
    Do While (y * 100 + p) <= (toY * 100 + toP)
        summary = summary & JobLine("Inventory " & Format$(p, "000") & "/" & y, _
                                    JobInventory(Format$(p, "000"), CStr(y), sParts), nOk, nFail)
        p = p + 1
        If p > 12 Then p = 1: y = y + 1
    Loop
    FinishBatch summary, nOk, nFail, t0, "Inventory month-end"
    RunInventoryMonthEnd = (nFail = 0)
End Function

Public Function RunKE24Backfill() As Boolean
    Dim sN As String, n As Long, m As Long, dt As Date
    Dim summary As String, nOk As Long, nFail As Long, t0 As Date, res As String

    sN = InputBox("How many closed months should be re-extracted from KE24?" & vbCrLf & _
                  "(Each month takes a few minutes.)", "KE24 backfill", "6")
    If Not IsNumeric(sN) Then Exit Function
    n = CLng(sN)
    If n < 1 Or n > 36 Then Exit Function

    t0 = Now
    If Not StartBatch() Then Exit Function
    For m = n To 1 Step -1
        dt = DateAdd("m", -m, Date)
        res = JobKE24(Format$(Month(dt), "000"), CStr(Year(dt)), "MonthEnd")
        summary = summary & JobLine("KE24 " & Format$(Month(dt), "000") & "." & Year(dt), res, nOk, nFail)
        PauseSeconds 1
    Next m
    FinishBatch summary, nOk, nFail, t0, "KE24 backfill"
    RunKE24Backfill = (nFail = 0)
End Function

Public Function RunForecastImport() As Boolean
    Dim files As Collection, res As String, summary As String, nOk As Long, nFail As Long
    Set files = BrowseForFiles("Select Forecast Excel File", False)
    If files.Count = 0 Then Exit Function
    If Not StartBatch() Then Exit Function
    res = JobForecast(CStr(files(1)))
    If Left$(res, 9) = "CANCELLED" Then Exit Function
    summary = JobLine("Forecast", res, nOk, nFail)
    FinishBatch summary, nOk, nFail, Now, "Forecast import"
    RunForecastImport = (nFail = 0)
End Function

Public Function RunProvisionImport() As Boolean
    Dim res As String, summary As String, nOk As Long, nFail As Long
    If Not StartBatch() Then Exit Function
    res = JobProvisions()
    If Left$(res, 9) = "CANCELLED" Then Exit Function
    summary = JobLine("Provisions", res, nOk, nFail)
    FinishBatch summary, nOk, nFail, Now, "Provision import"
    RunProvisionImport = (nFail = 0)
End Function

Public Function RunSnapshotBackfill() As Boolean
    Dim res As String, summary As String, nOk As Long, nFail As Long
    If Not StartBatch() Then Exit Function
    res = JobSnapshotBackfill()
    If Left$(res, 9) = "CANCELLED" Then Exit Function
    summary = JobLine("Daily snapshot backfill", res, nOk, nFail)
    FinishBatch summary, nOk, nFail, Now, "Snapshot backfill"
    RunSnapshotBackfill = (nFail = 0)
End Function

' ============================================================================
'   JOBS  (each returns "OK - ...", "NOT NEEDED - ..." or "FAILED - ...")
' ============================================================================

' --- S_P99 inventory: blank period = today's snapshot, else month-end --------
Private Function JobInventory(ByVal sPeriod As String, ByVal sYear As String, _
                              ByVal sParts As String, Optional ByVal deferProcessing As Boolean = False) As String
    Dim sess As Object, sapFile As String, feed As String, t As Double
    Dim outLines() As String, nRows As Long, clipText As String, oClip As Object
    On Error GoTo Fail

    feed = IIf(Len(sPeriod) = 0, "inv_daily", "inv_month")
    sapFile = NewExportPath(feed)
    t = Timer
    Set sess = UseSAP(INV_TCODE)
    If sess Is Nothing Then JobInventory = "FAILED - could not open SAP session": Exit Function

    ' ---- recorded SAP steps (from mod_SAP_Export.RunSAPExport) ----
    On Error Resume Next
    If Len(sPeriod) > 0 Then
        sess.findById("wnd[0]/usr/txtP_POPER").Text = sPeriod: SapErr "set period"
    End If
    If Len(sYear) > 0 Then
        sess.findById("wnd[0]/usr/txtP_BDATJ").Text = sYear: SapErr "set year"
    End If
    sess.findById("wnd[0]/usr/ctxtP_VARIAN").Text = INV_VARIANT: SapErr "set variant"

    clipText = PartsToClip(sParts)
    If Len(clipText) > 0 Then
        sess.findById("wnd[0]/usr/ctxtP_MATNR").SetFocus
        sess.findById("wnd[0]/usr/btn%_P_MATNR_%_APP_%-VALU_PUSH").press
        Set oClip = CreateObject("New:{1C3B4210-F441-11CE-B9EA-00AA006B1A69}")
        oClip.SetText clipText
        oClip.PutInClipboard
        sess.findById("wnd[1]/tbar[0]/btn[24]").press
        sess.findById("wnd[1]/tbar[0]/btn[8]").press
        SapErr "part filter"
    End If

    sess.findById("wnd[0]/tbar[1]/btn[8]").press: SapErr "execute report"
    sess.findById("wnd[0]/tbar[1]/btn[45]").press: SapErr "export menu"
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").Select: SapErr "select format"
    sess.findById("wnd[1]/tbar[0]/btn[0]").press: SapErr "confirm format"
    sess.findById("wnd[1]/usr/ctxtDY_PATH").Text = SAP_EXPORT_DIR: SapErr "set path"
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").Text = Fso.GetFileName(sapFile): SapErr "set filename"
    sess.findById("wnd[1]/tbar[0]/btn[0]").press: SapErr "save file"
    On Error GoTo Fail
    ' ---- end recorded steps ----

    If deferProcessing Then
        If Not WaitForFileCreated(sapFile, FILE_WAIT_SECS) Then
            JobInventory = "FAILED - SAP did not write the export file": Exit Function
        End If
        LogStep "SAP extract", t
        JobInventory = "QUEUED|" & sapFile
        Exit Function
    End If
    LogStep "SAP extract", t
    JobInventory = ProcessInventory(sapFile, sPeriod, sYear)
    Exit Function
Fail:
    JobInventory = "FAILED - " & Err.Description
    LogMsg "JobInventory error " & Err.Number & ": " & Err.Description
    On Error Resume Next
    ResetSAP sess
End Function

' Read the SAP export, write the lakehouse file and queue its upload
Private Function ProcessInventory(ByVal sapFile As String, ByVal sPeriod As String, ByVal sYear As String) As String
    If Len(sPeriod) = 0 Then
        ProcessInventory = QueueRawFile(sapFile, "inv_daily_raw")
    Else
        ProcessInventory = QueueRawFile(sapFile, "inv_month_raw", "P" & sPeriod & "_" & sYear)
    End If
End Function

' --- MB52 storage-location stock -------------------------------------------
Private Function JobMB52(Optional ByVal deferProcessing As Boolean = False) As String
    Dim sess As Object, sapFile As String, outLines() As String, nRows As Long, t As Double
    On Error GoTo Fail

    sapFile = NewExportPath("mb52")
    t = Timer
    Set sess = UseSAP(MB52_TCODE)
    If sess Is Nothing Then JobMB52 = "FAILED - could not open SAP session": Exit Function
    WaitSAPIdle sess, 0.5                            ' let the screen settle

    ' ---- recorded SAP steps (from mod_SAP_Export.ExportMB52) ----
    On Error Resume Next
    sess.findById("wnd[0]/usr/btn%_MATNR_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_LGORT_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/chkPA_SOND").Selected = True
    sess.findById("wnd[0]/usr/ctxtWERKS-LOW").Text = MB52_PLANT
    sess.findById("wnd[0]/usr/chkPA_SOND").SetFocus
    sess.findById("wnd[0]").sendVKey 2
    sess.findById("wnd[0]/usr/ctxtP_VARI").Text = MB52_VARIANT
    sess.findById("wnd[0]/usr/ctxtP_VARI").SetFocus
    sess.findById("wnd[0]/usr/ctxtP_VARI").CaretPosition = 12
    SapErr "MB52 selection screen"
    On Error GoTo Fail

    sess.findById("wnd[0]/tbar[1]/btn[8]").press
    WaitSAPIdle sess, 0.3

    On Error Resume Next
    sess.findById("wnd[0]/tbar[1]/btn[45]").press
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").Select
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").SetFocus
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    sess.findById("wnd[1]/usr/ctxtDY_PATH").Text = SAP_EXPORT_DIR
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").Text = Fso.GetFileName(sapFile)
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").CaretPosition = Len(Fso.GetFileName(sapFile))
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    SapErr "MB52 export dialog"
    On Error GoTo Fail
    ' ---- end recorded steps ----

    If deferProcessing Then
        If Not WaitForFileCreated(sapFile, FILE_WAIT_SECS) Then
            JobMB52 = "FAILED - SAP did not write the export file": Exit Function
        End If
        LogStep "SAP extract", t
        JobMB52 = "QUEUED|" & sapFile
        Exit Function
    End If
    LogStep "SAP extract", t
    JobMB52 = ProcessMB52(sapFile)
    Exit Function
Fail:
    JobMB52 = "FAILED - " & Err.Description
    LogMsg "JobMB52 error " & Err.Number & ": " & Err.Description
    On Error Resume Next
    ResetSAP sess
End Function

' Read the SAP export, write the lakehouse file and queue its upload
Private Function ProcessMB52(ByVal sapFile As String) As String
    ProcessMB52 = QueueRawFile(sapFile, "mb52_raw")
End Function

' --- KE24 for one period.  runKind = "Current" or "MonthEnd" -----------------
Private Function JobKE24(ByVal sPeriod As String, ByVal sYear As String, _
                         ByVal runKind As String, Optional ByVal deferProcessing As Boolean = False) As String
    Dim sess As Object, sapFile As String, outLines() As String, nRows As Long
    Dim sSAPPeriod As String, oWnd1 As Object, t As Double, sNoData As String
    On Error GoTo Fail

    sapFile = NewExportPath("ke24")
    t = Timer
    Set sess = UseSAP(KE24_TCODE)
    If sess Is Nothing Then JobKE24 = "FAILED - could not open SAP session": Exit Function

    ' ---- recorded SAP steps (from mod_KE24_Extract, recording 2026-04-09) ----
    On Error Resume Next
    Set oWnd1 = sess.findById("wnd[1]/usr/ctxtRKEA2-ERKRS")      ' Operating Concern popup (may not appear)
    If Err.Number = 0 And Not oWnd1 Is Nothing Then
        oWnd1.Text = KE24_OP_CONCERN
        oWnd1.CaretPosition = 4
        Err.Clear
        sess.findById("wnd[1]/tbar[0]/btn[0]").press: SapErr "op concern confirm"
        WaitSAPIdle sess
    End If
    Err.Clear
    Set oWnd1 = Nothing

    sess.findById("wnd[0]/tbar[1]/btn[17]").press: SapErr "get variant"
    WaitSAPIdle sess
    sess.findById("wnd[1]/usr/txtSO_ENAM-LOW").Text = KE24_VARIANT_USER: SapErr "variant user"
    sess.findById("wnd[1]/usr/txtSO_ENAM-LOW").SetFocus
    sess.findById("wnd[1]/usr/txtSO_ENAM-LOW").CaretPosition = Len(KE24_VARIANT_USER)
    Err.Clear
    sess.findById("wnd[1]/tbar[0]/btn[8]").press: SapErr "variant execute"
    WaitSAPIdle sess
    sess.findById("wnd[1]/usr/cntlGRID1/shellcont/shell").SelectedRows = "0": SapErr "variant grid select"
    sess.findById("wnd[1]/usr/cntlGRID1/shellcont/shell").DoubleClickCurrentCell: SapErr "variant grid open"
    WaitSAPIdle sess

    sSAPPeriod = sPeriod & "." & sYear
    sess.findById("wnd[0]/usr/txtPERIO-LOW").Text = sSAPPeriod: SapErr "PERIO-LOW"
    sess.findById("wnd[0]/usr/ctxtFADAT-LOW").Text = "": SapErr "FADAT-LOW clear"
    sess.findById("wnd[0]/usr/ctxtFADAT-HIGH").Text = "": SapErr "FADAT-HIGH clear"
    sess.findById("wnd[0]/usr/txtPERIO-LOW").SetFocus
    sess.findById("wnd[0]/usr/txtPERIO-LOW").CaretPosition = Len(sSAPPeriod)
    Err.Clear
    On Error GoTo Fail

    sess.findById("wnd[0]/tbar[1]/btn[8]").press
    WaitSAPIdle sess, 0.3

    ' v2.2: no line items for the period (normal for the current period on the 1st of the
    ' month) -> SAP stays on the selection screen and Export gives "Choose a valid function".
    sNoData = KE24NoDataMessage(sess)
    If Len(sNoData) > 0 Then
        LogStep "SAP extract", t
        LogMsg "KE24 " & runKind & " " & sSAPPeriod & ": no report list - " & sNoData
        If runKind = "MonthEnd" Then
            JobKE24 = "FAILED - KE24 returned no line items for " & sSAPPeriod & " (" & sNoData & ")"
        Else
            JobKE24 = "OK - no KE24 line items posted yet for " & sSAPPeriod & " (" & sNoData & ")"
        End If
        Exit Function
    End If

    On Error Resume Next
    sess.findById("wnd[0]/tbar[1]/btn[9]").press: SapErr "export btn[9]"
    WaitSAPIdle sess
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").Select: SapErr "select format"
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").SetFocus
    Err.Clear
    sess.findById("wnd[1]/tbar[0]/btn[0]").press: SapErr "confirm format"
    WaitSAPIdle sess
    sess.findById("wnd[1]/usr/ctxtDY_PATH").Text = SAP_EXPORT_DIR: SapErr "DY_PATH"
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").Text = Fso.GetFileName(sapFile): SapErr "DY_FILENAME"
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").CaretPosition = Len(Fso.GetFileName(sapFile))
    Err.Clear
    sess.findById("wnd[1]/tbar[0]/btn[0]").press: SapErr "save confirm"
    WaitSAPIdle sess                                   ' v2.2: let SAP finish before the next job
    On Error GoTo Fail
    ' ---- end recorded steps ----

    If deferProcessing Then
        If Not WaitForFileCreated(sapFile, FILE_WAIT_SECS) Then
            JobKE24 = "FAILED - SAP did not write the export file": Exit Function
        End If
        LogStep "SAP extract", t
        JobKE24 = "QUEUED|" & sapFile
        Exit Function
    End If
    LogStep "SAP extract", t
    JobKE24 = ProcessKE24(sapFile, sPeriod, sYear, runKind)
    Exit Function
Fail:
    JobKE24 = "FAILED - " & Err.Description
    LogMsg "JobKE24 error " & Err.Number & ": " & Err.Description
    On Error Resume Next
    ResetSAP sess
End Function

' v2.2: after KE24 Execute - returns SAP's message if no report list was produced
' (still on the selection screen), otherwise "". Closes an info popup if one is open.
Private Function KE24NoDataMessage(ByVal sess As Object) As String
    Dim o As Object, msg As String
    On Error Resume Next
    If sess.Children.Count > 1 Then                    ' e.g. "No data selected" info popup
        Set o = sess.findById("wnd[1]/usr/txtMESSTXT1", False)
        If Not o Is Nothing Then msg = Trim$(o.Text) Else msg = Trim$(sess.findById("wnd[1]").Text)
        Err.Clear
        sess.findById("wnd[1]").sendVKey 0
        WaitSAPIdle sess, 0.1
    End If
    Set o = Nothing
    Set o = sess.findById("wnd[0]/usr/txtPERIO-LOW", False)   ' only exists on the selection screen
    If Not o Is Nothing Then
        If Len(msg) = 0 Then msg = Trim$(sess.findById("wnd[0]/sbar").Text)
        If Len(msg) = 0 Then msg = "SAP returned no report list"
        KE24NoDataMessage = msg
    End If
    Err.Clear
End Function

' Read the SAP export, write the lakehouse file and queue its upload
Private Function ProcessKE24(ByVal sapFile As String, ByVal sPeriod As String, ByVal sYear As String, ByVal runKind As String) As String
    ProcessKE24 = QueueRawFile(sapFile, "ke24_raw", runKind & "_" & sPeriod & "_" & sYear)
End Function

' --- Forecast workbook (Format A Finance "Forecast" / Format B *_Finance_FCST)
Private Function JobForecast(ByVal sFilePath As String) As String
    Dim xlApp As Object, wb As Object, ws As Object, sh As Object
    Dim sFormat As String, sSheetName As String, sPeriod As String, sYear As String
    Dim sInput As String, scanRow As Long, lastScanRow As Long
    Dim hdrRowQty As Long, hdrRowVal As Long, endRowQty As Long, endRowVal As Long
    Dim nQtyCol As Long, nValCol As Long, sPLabel As String
    Dim aCust As Variant, aQty As Variant, aVal As Variant, aValCust As Variant
    Dim dictVal As Object, i As Long, v As Long, n As Long
    Dim sCust As String, dQty As Double, dVal As Double, sSource As String
    Dim outLines() As String
    On Error GoTo Fail

    Set xlApp = CreateObject("Excel.Application")
    xlApp.Visible = False: xlApp.DisplayAlerts = False
    Set wb = xlApp.Workbooks.Open(sFilePath, False, True)

    For Each sh In wb.Sheets
        If sh.name Like "*_Finance_FCST" Then sFormat = "B": sSheetName = sh.name: Exit For
    Next sh
    If Len(sFormat) = 0 Then
        For Each sh In wb.Sheets
            If StrComp(sh.name, "Forecast", vbTextCompare) = 0 Then sFormat = "A": sSheetName = sh.name: Exit For
        Next sh
    End If
    If Len(sFormat) = 0 Then JobForecast = "FAILED - no 'Forecast' or '*_Finance_FCST' sheet": GoTo Cleanup
    Set ws = wb.Sheets(sSheetName)

    sPeriod = Format$(Month(Date), "000"): sYear = CStr(Year(Date))
    sInput = InputBox("Target period (1-12):" & vbCrLf & vbCrLf & _
                      "Detected format: " & IIf(sFormat = "B", "DCC Tool", "Finance Native") & vbCrLf & _
                      "Sheet: " & sSheetName, "Forecast Import", CLng(sPeriod))
    If Len(Trim$(sInput)) = 0 Then JobForecast = "CANCELLED": GoTo Cleanup
    If IsNumeric(sInput) Then sPeriod = Format$(CLng(sInput), "000")
    sInput = InputBox("Fiscal year:", "Forecast Import", sYear)
    If Len(Trim$(sInput)) = 0 Then JobForecast = "CANCELLED": GoTo Cleanup
    sYear = Trim$(sInput)

    ' Units block: first P1 in col B -> "Total IC" in col A; Value block: next P1 -> next "Total IC"
    lastScanRow = ws.Cells(ws.Rows.Count, 2).End(-4162).Row
    For scanRow = 1 To lastScanRow
        If StrComp(CleanHeader(NzS(ws.Cells(scanRow, 2).Value)), "P1", vbTextCompare) = 0 Then hdrRowQty = scanRow: Exit For
    Next scanRow
    If hdrRowQty = 0 Then JobForecast = "FAILED - could not find 'P1' in column B": GoTo Cleanup
    For scanRow = hdrRowQty + 1 To lastScanRow + 20
        If StrComp(Trim$(NzS(ws.Cells(scanRow, 1).Value)), "Total IC", vbTextCompare) = 0 Then endRowQty = scanRow - 1: Exit For
    Next scanRow
    If endRowQty > 0 Then
        For scanRow = endRowQty + 1 To lastScanRow + 20
            If StrComp(CleanHeader(NzS(ws.Cells(scanRow, 2).Value)), "P1", vbTextCompare) = 0 Then hdrRowVal = scanRow: Exit For
        Next scanRow
    End If
    If hdrRowVal > 0 Then
        For scanRow = hdrRowVal + 1 To lastScanRow + 20
            If StrComp(Trim$(NzS(ws.Cells(scanRow, 1).Value)), "Total IC", vbTextCompare) = 0 Then endRowVal = scanRow - 1: Exit For
        Next scanRow
    End If

    sPLabel = "P" & CLng(sPeriod)
    nQtyCol = FindPeriodCol(ws, hdrRowQty, sPLabel)
    If nQtyCol = 0 Then JobForecast = "FAILED - no '" & sPLabel & "' column in units header": GoTo Cleanup
    If hdrRowVal > 0 Then nValCol = FindPeriodCol(ws, hdrRowVal, sPLabel)

    If endRowQty = 0 Then endRowQty = LastFilledRowA(ws, hdrRowQty + 1)
    If endRowQty < hdrRowQty + 1 Then JobForecast = "FAILED - no data rows in units block": GoTo Cleanup
    aCust = ws.Range(ws.Cells(hdrRowQty + 1, 1), ws.Cells(endRowQty, 1)).Value
    aQty = ws.Range(ws.Cells(hdrRowQty + 1, nQtyCol), ws.Cells(endRowQty, nQtyCol)).Value
    If Not IsArray(aCust) Then JobForecast = "FAILED - units block needs at least 2 rows": GoTo Cleanup

    Set dictVal = CreateObject("Scripting.Dictionary"): dictVal.CompareMode = 1
    If hdrRowVal > 0 And nValCol > 0 Then
        If endRowVal = 0 Then endRowVal = LastFilledRowA(ws, hdrRowVal + 1)
        If endRowVal > hdrRowVal + 1 Then
            aValCust = ws.Range(ws.Cells(hdrRowVal + 1, 1), ws.Cells(endRowVal, 1)).Value
            aVal = ws.Range(ws.Cells(hdrRowVal + 1, nValCol), ws.Cells(endRowVal, nValCol)).Value
            For v = 1 To UBound(aVal, 1)
                sCust = Trim$(NzS(aValCust(v, 1)))
                If Len(sCust) > 0 And Left$(UCase$(sCust), 5) <> "TOTAL" Then dictVal(sCust) = SafeDbl(aVal(v, 1)) * 1000
            Next v
        End If
    End If
    wb.Close False: Set wb = Nothing
    xlApp.Quit: Set xlApp = Nothing

    sSource = IIf(sFormat = "B", "DCC_Tool", "Finance")
    ReDim outLines(0 To UBound(aCust, 1))
    outLines(0) = "Forecast_Source|Import_Date|Customer_Name|Period|Fiscal_Year|Forecast_Qty|Forecast_Value"
    For i = 1 To UBound(aCust, 1)
        sCust = Trim$(NzS(aCust(i, 1)))
        If Len(sCust) = 0 Then GoTo NextRow
        If Left$(UCase$(sCust), 5) = "TOTAL" Then GoTo NextRow
        dQty = Round(SafeDbl(aQty(i, 1)), 0)
        dVal = 0
        If dictVal.Exists(sCust) Then dVal = dictVal(sCust)
        If dVal = 0 And dQty = 0 Then GoTo NextRow
        n = n + 1
        outLines(n) = CsvField(sSource) & PIPE & IsoDate(Date) & PIPE & CsvField(sCust) & PIPE & _
                      sPeriod & PIPE & CsvField(sYear) & PIPE & NumStr(dQty) & PIPE & NumStr(dVal)
NextRow:
    Next i
    If n = 0 Then JobForecast = "FAILED - no forecast rows found for " & sPLabel: Exit Function
    ReDim Preserve outLines(0 To n)
    DropFeed "forecast", outLines
    JobForecast = "OK - " & n & " customers for period " & sPeriod & "/" & sYear
    Exit Function

Cleanup:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close False
    If Not xlApp Is Nothing Then xlApp.Quit
    Exit Function
Fail:
    JobForecast = "FAILED - " & Err.Description
    LogMsg "JobForecast error " & Err.Number & ": " & Err.Description
    Resume Cleanup
End Function

' --- E&O provisions (Finance workbooks, "Stock" sheet by default) ------------
Private Function JobProvisions() As String
    Dim strFrom As String, strTo As String, effFrom As Date, effTo As Date
    Dim resp As VbMsgBoxResult, loadMode As String, files As Collection, sheetName As String
    Dim f As Variant, lines As Collection, nFiles As Long, nSkipped As Long
    Dim outLines() As String, i As Long
    On Error GoTo Fail

    strFrom = InputBox("Effective From date for this provision set (DD/MM/YYYY):", "Provision Effective From", "01/01/" & Year(Date))
    If strFrom = "" Then JobProvisions = "CANCELLED": Exit Function
    strTo = InputBox("Effective To date (DD/MM/YYYY):", "Provision Effective To", "31/03/" & Year(Date))
    If strTo = "" Then JobProvisions = "CANCELLED": Exit Function
    If Not TryParseDateDMY(strFrom, effFrom) Or Not TryParseDateDMY(strTo, effTo) Then
        MsgBox "Dates must be DD/MM/YYYY.", vbExclamation: JobProvisions = "CANCELLED": Exit Function
    End If
    If effTo < effFrom Then MsgBox "Effective To cannot be before Effective From.", vbExclamation: JobProvisions = "CANCELLED": Exit Function

    resp = MsgBox("Replace any provisions already held that overlap " & Format$(effFrom, "dd/mm/yyyy") & _
                  " to " & Format$(effTo, "dd/mm/yyyy") & "?" & vbCrLf & vbCrLf & _
                  "Yes = delete overlapping rows and re-import" & vbCrLf & _
                  "No = append alongside existing" & vbCrLf & "Cancel = abort", _
                  vbYesNoCancel + vbQuestion, "Provision Import")
    If resp = vbCancel Then JobProvisions = "CANCELLED": Exit Function
    loadMode = IIf(resp = vbYes, "REPLACE", "APPEND")

    Set files = BrowseForFiles("Select Finance Provision Workbook(s)", True)
    If files.Count = 0 Then JobProvisions = "CANCELLED": Exit Function
    sheetName = InputBox("Sheet name containing the provision data:", "Sheet Name", "Stock")
    If sheetName = "" Then JobProvisions = "CANCELLED": Exit Function

    Set lines = New Collection
    lines.Add "Material_ID|Val_Type|ValCl|Total_Provision|Effective_From|Effective_To|Load_Mode"
    For Each f In files
        ReadProvisionFile CStr(f), sheetName, effFrom, effTo, loadMode, lines, nSkipped
        nFiles = nFiles + 1
    Next f
    If lines.Count <= 1 Then JobProvisions = "FAILED - no non-zero provision rows found": Exit Function

    ReDim outLines(0 To lines.Count - 1)
    For i = 1 To lines.Count: outLines(i - 1) = lines(i): Next i
    DropFeed "provision", outLines
    JobProvisions = "OK - " & (lines.Count - 1) & " rows from " & nFiles & " file(s), " & _
                    nSkipped & " zero rows skipped (" & loadMode & ")"
    Exit Function
Fail:
    JobProvisions = "FAILED - " & Err.Description
    LogMsg "JobProvisions error " & Err.Number & ": " & Err.Description
End Function

' --- Backfill tbl_DailySnapshot for one date from an Excel file --------------
Private Function JobSnapshotBackfill() As String
    Dim files As Collection, inputDate As String, snapDate As Date
    Dim xlApp As Object, wb As Object, ws As Object, srcData As Variant
    Dim lastRow As Long, lastCol As Long, colMap As Object, c As Long, r As Long, hdr As String
    Dim outLines() As String, n As Long, matVal As String
    On Error GoTo Fail

    Set files = BrowseForFiles("Select Excel file for Daily Snapshot backfill", False)
    If files.Count = 0 Then JobSnapshotBackfill = "CANCELLED": Exit Function
    inputDate = InputBox("Snapshot date (DD/MM/YYYY):", "Backfill Daily Snapshot")
    If Len(Trim$(inputDate)) = 0 Then JobSnapshotBackfill = "CANCELLED": Exit Function
    If Not TryParseDateDMY(inputDate, snapDate) Then
        MsgBox "Invalid date: " & inputDate, vbExclamation: JobSnapshotBackfill = "CANCELLED": Exit Function
    End If
    If MsgBox("Any data already held for " & Format$(snapDate, "dd/mm/yyyy") & " will be replaced. Continue?", _
              vbYesNo + vbQuestion) <> vbYes Then JobSnapshotBackfill = "CANCELLED": Exit Function

    Set xlApp = CreateObject("Excel.Application")
    xlApp.Visible = False: xlApp.DisplayAlerts = False
    Set wb = xlApp.Workbooks.Open(CStr(files(1)), False, True)
    Set ws = wb.Sheets(1)
    lastRow = ws.Cells(ws.Rows.Count, 1).End(-4162).Row
    lastCol = ws.Cells(1, ws.Columns.Count).End(-4159).Column
    If lastRow < 2 Then JobSnapshotBackfill = "FAILED - no data rows in file": GoTo Cleanup
    srcData = ws.Range(ws.Cells(1, 1), ws.Cells(lastRow, lastCol)).Value
    wb.Close False: Set wb = Nothing
    xlApp.Quit: Set xlApp = Nothing

    Set colMap = CreateObject("Scripting.Dictionary"): colMap.CompareMode = 1
    For c = 1 To UBound(srcData, 2)
        hdr = Trim$(NzS(srcData(1, c)))
        If Len(hdr) > 0 And Not colMap.Exists(hdr) Then colMap.Add hdr, c
    Next c
    If Not (colMap.Exists("Material") And colMap.Exists("Total stock") And colMap.Exists("Total value")) Then
        JobSnapshotBackfill = "FAILED - file needs 'Material', 'Total stock' and 'Total value' headers": Exit Function
    End If

    ReDim outLines(0 To UBound(srcData, 1))
    outLines(0) = "Snapshot_Date|Material_ID|Val_Type|ValCl|Total_Stock|Std_Price|PerUnitPr|Per|Price_Control|Total_Value"
    For r = 2 To UBound(srcData, 1)
        matVal = Trim$(NzS(srcData(r, colMap("Material"))))
        If Len(matVal) = 0 Then GoTo NextRow
        n = n + 1
        outLines(n) = IsoDate(snapDate) & PIPE & CsvField(matVal) & PIPE & _
            CsvField(MapStr(srcData, r, colMap, "Valuation Type")) & PIPE & _
            CsvField(MapStr(srcData, r, colMap, "Valuation Class")) & PIPE & _
            NumStr(SafeDbl(srcData(r, colMap("Total stock")))) & PIPE & _
            MapNum(srcData, r, colMap, "Standard price") & PIPE & _
            MapNum(srcData, r, colMap, "Periodic unit price") & PIPE & _
            CsvField(MapStr(srcData, r, colMap, "Price unit")) & PIPE & _
            CsvField(MapStr(srcData, r, colMap, "Price control")) & PIPE & _
            NumStr(SafeDbl(srcData(r, colMap("Total value"))))
NextRow:
    Next r
    If n = 0 Then JobSnapshotBackfill = "FAILED - no material rows": Exit Function
    ReDim Preserve outLines(0 To n)
    DropFeed "snapshot_backfill", outLines
    JobSnapshotBackfill = "OK - " & n & " rows for " & Format$(snapDate, "dd/mm/yyyy")
    Exit Function

Cleanup:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close False
    If Not xlApp Is Nothing Then xlApp.Quit
    Exit Function
Fail:
    JobSnapshotBackfill = "FAILED - " & Err.Description
    LogMsg "JobSnapshotBackfill error " & Err.Number & ": " & Err.Description
    Resume Cleanup
End Function

' ============================================================================
'   EXCEL READERS  (Finance provision workbooks)
' ============================================================================

Private Sub ReadProvisionFile(ByVal filePath As String, ByVal sheetName As String, _
                              ByVal effFrom As Date, ByVal effTo As Date, ByVal loadMode As String, _
                              ByRef lines As Collection, ByRef nSkipped As Long)
    Dim xl As Object, wb As Object, ws As Object, data As Variant
    Dim lastRow As Long, lastCol As Long, r As Long, c As Long
    Dim colMat As Long, colValCl As Long, colValType As Long, colProv As Long
    Dim provVal As Double, missing As String, tail As String

    Set xl = CreateObject("Excel.Application")
    xl.Visible = False: xl.DisplayAlerts = False
    On Error Resume Next
    Set wb = xl.Workbooks.Open(filePath, False, True)
    If wb Is Nothing Then MsgBox "Could not open: " & filePath, vbExclamation: xl.Quit: Exit Sub
    Set ws = wb.Sheets(sheetName)
    If ws Is Nothing Then
        MsgBox "Sheet '" & sheetName & "' not found in: " & Dir(filePath), vbExclamation
        wb.Close False: xl.Quit: Exit Sub
    End If
    On Error GoTo 0

    lastRow = ws.Cells(ws.Rows.Count, 1).End(-4162).Row
    lastCol = ws.Cells(1, ws.Columns.Count).End(-4159).Column
    If lastRow < 2 Then MsgBox "No data rows in: " & Dir(filePath), vbExclamation: wb.Close False: xl.Quit: Exit Sub
    data = ws.Range(ws.Cells(1, 1), ws.Cells(lastRow, lastCol)).Value
    wb.Close False: xl.Quit: Set xl = Nothing

    For c = 1 To lastCol
        Select Case Trim$(NzS(data(1, c)))
            Case "Material":        colMat = c
            Case "Valuation Class": colValCl = c
            Case "Valuation Type":  colValType = c
            Case "Total Provision": colProv = c
        End Select
    Next c
    If colMat = 0 Then missing = missing & "Material, "
    If colValCl = 0 Then missing = missing & "Valuation Class, "
    If colValType = 0 Then missing = missing & "Valuation Type, "
    If colProv = 0 Then missing = missing & "Total Provision, "
    If Len(missing) > 0 Then
        MsgBox "Missing columns in " & Dir(filePath) & ":" & vbCrLf & Left$(missing, Len(missing) - 2), vbExclamation
        Exit Sub
    End If

    tail = PIPE & IsoDate(effFrom) & PIPE & IsoDate(effTo) & PIPE & loadMode
    For r = 2 To lastRow
        provVal = 0
        If Not IsEmpty(data(r, colProv)) And Not IsError(data(r, colProv)) Then
            If IsNumeric(data(r, colProv)) Then provVal = CDbl(data(r, colProv))
        End If
        If provVal <> 0 Then
            lines.Add CsvField(Trim$(NzS(data(r, colMat)))) & PIPE & CsvField(Trim$(NzS(data(r, colValType)))) & PIPE & _
                      CsvField(Trim$(NzS(data(r, colValCl)))) & PIPE & NumStr(provVal) & tail
        Else
            nSkipped = nSkipped + 1
        End If
    Next r
End Sub

' ============================================================================
'   LANDING / BATCH  (complete files only + a "_ready" batch file last)
' ============================================================================

Private Function StartBatch() As Boolean
    If Not Fso.FolderExists(SAP_EXPORT_DIR) Then CreateFolderPath SAP_EXPORT_DIR
    ' One check that OneLake File Explorer is running (robocopy creates the landing folders itself)
    If Not Fso.FolderExists(LakehouseFilesRoot()) Then
        MsgBox "Can't find the lakehouse folder:" & vbCrLf & LakehouseFilesRoot() & vbCrLf & vbCrLf & _
               "Check OneLake File Explorer is running and signed in, and that the workspace / " & _
               "lakehouse names at the top of the DailyRefresh module match Fabric.", vbCritical, "Daily refresh"
        Exit Function
    End If
    Set m_batch = New Collection
    m_seq = 0
    m_mark = Timer
    TidyUploadLogs
    RequeueLeftovers
    StartBatch = True
End Function

' Write the finished file to the local outbox, then hand it to a background robocopy.
' The macro carries straight on with the next SAP job while the file uploads.
Private Sub DropFeed(ByVal feed As String, ByRef outLines() As String)
    Dim boxDir As String, fileName As String
    boxDir = OutboxRoot() & feed & "\"
    If Not Fso.FolderExists(boxDir) Then CreateFolderPath boxDir
    Do
        m_seq = m_seq + 1
        fileName = feed & "_" & Format$(Now, "yyyymmdd_hhnnss") & "_" & m_seq & ".csv"
    Loop While Fso.FileExists(boxDir & fileName)
    WriteUtf8 boxDir & fileName, Join(outLines, vbCrLf) & vbCrLf
    m_batch.Add feed & "/" & fileName & PIPE & Fso.GetFile(boxDir & fileName).Size
    StartUpload feed, fileName
    LogMsg "Queued " & feed & "/" & fileName & " (" & UBound(outLines) & " rows) - uploading in background"
End Sub

' Last file = the pipeline trigger. A small background script waits until every feed file
' of this run has left the outbox (i.e. reached OneLake), then uploads the batch file.
Private Sub FinishBatch(ByVal summary As String, ByVal nOk As Long, ByVal nFail As Long, _
                        ByVal t0 As Date, ByVal title As String, Optional ByVal showDialog As Boolean = True)
    Dim fileName As String, body As String, i As Long, cmd As String, ts As Object, rel As String
    m_lastBatchFile = ""
    Set m_lastItems = Nothing
    If m_batch Is Nothing Then Exit Sub
    EndSAP
    If m_batch.Count > 0 Then
        If Not Fso.FolderExists(OutboxRoot() & "_ready\") Then CreateFolderPath OutboxRoot() & "_ready\"
        For i = 1 To m_batch.Count: body = body & m_batch(i) & vbCrLf: Next i
        fileName = "batch_" & Format$(Now, "yyyymmdd_hhnnss") & ".txt"
        Set ts = Fso.CreateTextFile(OutboxRoot() & "_ready\" & fileName, True, False)   ' plain text, no BOM
        ts.Write body
        ts.Close

        cmd = OutboxRoot() & "send_" & Format$(Now, "yyyymmdd_hhnnss") & ".cmd"
        Set ts = Fso.CreateTextFile(cmd, True, False)
        ts.WriteLine "@echo off"
        ts.WriteLine "set n=0"
        ts.WriteLine ":wait"
        For i = 1 To m_batch.Count
            rel = Split(m_batch(i), PIPE)(0)
            ts.WriteLine "if exist """ & OutboxRoot() & Replace(rel, "/", "\") & """ goto more"
        Next i
        ts.WriteLine "goto send"
        ts.WriteLine ":more"
        ts.WriteLine "set /a n+=1"
        ts.WriteLine "if %n% GEQ 300 goto late"
        ts.WriteLine "ping -n 3 127.0.0.1 >nul"
        ts.WriteLine "goto wait"
        ts.WriteLine ":send"
        ts.WriteLine RobocopyLine("_ready", fileName)
        ts.WriteLine "echo %date% %time% upload complete - " & fileName & " >> """ & UploadLog() & """"
        ts.WriteLine "del ""%~f0"" & exit /b"
        ts.WriteLine ":late"
        ts.WriteLine "echo %date% %time% UPLOAD NOT FINISHED after 10 minutes - batch " & fileName & _
                     " held back; its files are re-sent with the next run >> """ & UploadLog() & """"
        ts.Close
        RunHidden """" & cmd & """"
        m_lastBatchFile = fileName
        Set m_lastItems = m_batch
        LogMsg "Batch " & fileName & " (" & m_batch.Count & " feed files) - sent when the uploads finish"
        summary = summary & vbCrLf & "SAP part done. The files are uploading to the lakehouse in the" & vbCrLf & _
                  "background; the tables and all three Power BI reports update by" & vbCrLf & _
                  "themselves in about 5-10 minutes. Keep the PC on and signed in until then."
    Else
        summary = summary & vbCrLf & "Nothing was sent to the lakehouse."
    End If
    summary = summary & vbCrLf & "Elapsed: " & Format$(Now - t0, "nn:ss")
    LogMsg title & " finished. OK=" & nOk & " Failed=" & nFail & " Elapsed=" & Format$(Now - t0, "nn:ss")
    If showDialog Then MsgBox summary, IIf(nFail = 0, vbInformation, vbExclamation), title
    Set m_batch = Nothing
End Sub

' Feed files left in the outbox by an earlier run (PC shut down mid-upload, network blip)
' are uploaded again and included in this run's batch. Stale batch files are dropped.
Private Sub RequeueLeftovers()
    Dim fld As Object, f As Object
    If Not Fso.FolderExists(OutboxRoot()) Then Exit Sub
    For Each fld In Fso.GetFolder(OutboxRoot()).SubFolders
        For Each f In fld.files
            If fld.name = "_ready" Then
                On Error Resume Next: f.Delete True: On Error GoTo 0
            ElseIf LCase$(Right$(f.name, 4)) = ".csv" Then
                m_batch.Add fld.name & "/" & f.name & PIPE & f.Size
                StartUpload fld.name, f.name
                LogMsg "Re-sending " & fld.name & "/" & f.name & " left over from an earlier run"
            End If
        Next f
    Next fld
End Sub

Private Sub StartUpload(ByVal feed As String, ByVal fileName As String)
    RunHidden "cmd /c " & RobocopyLine(feed, fileName)
End Sub

' robocopy /MOV removes the local file only once it is safely in OneLake;
' it retries by itself if OneLake File Explorer is briefly busy.
' Each copy writes its own small log (two copies can run at once, so they never share a file)
Private Function RobocopyLine(ByVal feed As String, ByVal fileName As String) As String
    RobocopyLine = "robocopy """ & OutboxRoot() & feed & """ """ & LandingRoot() & feed & """ """ & fileName & _
                   """ /MOV /R:20 /W:3 /NP /NJH /NJS /NDL > """ & UploadLogDir() & fileName & ".log"" 2>&1"
End Function

Private Sub RunHidden(ByVal commandLine As String)
    CreateObject("WScript.Shell").Run commandLine, 0, False
End Sub

Private Function OutboxRoot() As String
    OutboxRoot = SAP_EXPORT_DIR & "outbox\"
End Function

Private Function UploadLog() As String
    UploadLog = SAP_EXPORT_DIR & UPLOAD_LOG_NAME
End Function

Private Function UploadLogDir() As String
    UploadLogDir = SAP_EXPORT_DIR & "uploadlogs\"
End Function

' Keep a week of per-file upload logs
Private Sub TidyUploadLogs()
    Dim f As Object
    On Error Resume Next
    If Not Fso.FolderExists(UploadLogDir()) Then CreateFolderPath UploadLogDir(): Exit Sub
    For Each f In Fso.GetFolder(UploadLogDir()).files
        If f.DateLastModified < Now - 7 Then f.Delete True
    Next f
End Sub

Private Function JobLine(ByVal label As String, ByVal result As String, _
                         ByRef nOk As Long, ByRef nFail As Long) As String
    Dim isFail As Boolean
    Dim secs As Long
    isFail = (Left$(result, 6) = "FAILED")
    If isFail Then nFail = nFail + 1 Else nOk = nOk + 1
    secs = CLng(SecondsSince(m_mark))
    m_mark = Timer
    LogMsg label & ": " & result & " [" & secs & "s]"
    JobLine = IIf(isFail, "FAILED  ", "OK      ") & label & " - " & _
              Replace(Replace(Replace(result, "OK - ", ""), "FAILED - ", ""), "NOT NEEDED - ", "") & _
              " (" & secs & "s)" & vbCrLf
End Function

Private Function LakehouseFilesRoot() As String
    LakehouseFilesRoot = Environ$("USERPROFILE") & "\OneLake - Microsoft\" & FABRIC_WORKSPACE & "\" & _
                         FABRIC_LAKEHOUSE & ".Lakehouse\Files\"
End Function

Private Function LandingRoot() As String
    LandingRoot = LakehouseFilesRoot() & "landing\"
End Function

' A month is closed if the notebook has flagged it, or this PC already sent it
' Month (yyyymm) in which the KE24 month-end close last completed - a one-line local file
Private Function LastCloseMonth() As String
    Dim p As String, ts As Object
    p = SAP_EXPORT_DIR & "ke24_last_close_month.txt"
    If Not Fso.FileExists(p) Then
        ' Fresh install: last month was already closed by the old Access tool / history load,
        ' so start the marker at this month - the close then runs on the first run of next month
        SaveCloseMonth Format$(Date, "yyyymm")
        LastCloseMonth = Format$(Date, "yyyymm")
        Exit Function
    End If
    Set ts = Fso.OpenTextFile(p, 1)
    If Not ts.AtEndOfStream Then LastCloseMonth = Trim$(ts.ReadLine)
    ts.Close
End Function

Private Sub SaveCloseMonth(ByVal yyyymm As String)
    Dim ts As Object
    If Not Fso.FolderExists(SAP_EXPORT_DIR) Then CreateFolderPath SAP_EXPORT_DIR
    Set ts = Fso.CreateTextFile(SAP_EXPORT_DIR & "ke24_last_close_month.txt", True, False)
    ts.WriteLine yyyymm
    ts.Close
End Sub

' ============================================================================
'   SAP SESSION
' ============================================================================

' Bind to SAP GUI, open the transaction in a NEW session (/o), return it.
' Falls back to the current session if no new window appears within 10s.
Private Function GetSAPSession(ByVal sTCode As String) As Object
    Dim SapGuiAuto As Object, app As Object, conn As Object, oSess As Object, res As Object
    Dim before As Long, i As Long
    On Error GoTo ErrHandler

    Set SapGuiAuto = GetObject("SAPGUI")
    Set app = SapGuiAuto.GetScriptingEngine
    Set conn = app.Children(0)
    before = conn.Children.Count
    Set oSess = conn.Children(0)

    On Error Resume Next
    oSess.findById("wnd[0]/tbar[0]/okcd").Text = "/o" & sTCode
    oSess.findById("wnd[0]").sendVKey 0
    Err.Clear
    On Error GoTo ErrHandler

    For i = 1 To 20                                   ' 20 x 0.5s = 10s, midnight-safe
        If conn.Children.Count > before Then Exit For
        PauseSeconds 0.5
    Next i
    If conn.Children.Count > before Then
        Set res = conn.Children(conn.Children.Count - 1)
        m_sessOwned = True
    Else
        LogMsg "SAP: /o" & sTCode & " opened no new window - using the current session"
        oSess.findById("wnd[0]/tbar[0]/okcd").Text = "/n" & sTCode
        oSess.findById("wnd[0]").sendVKey 0
        Set res = oSess
        m_sessOwned = False                            ' the user's own window - never close it
    End If
    WaitSAPIdle res
    Set GetSAPSession = res
    Exit Function
ErrHandler:
    LogMsg "SAP: could not bind to SAP GUI (" & Err.Description & ") - is SAP open and logged on?"
    Set GetSAPSession = Nothing
End Function

' Session for the next job: the first job opens one new SAP window (/o); every later job
' reuses it with /n<tcode>, which saves opening and closing a window per job.
Private Function UseSAP(ByVal sTCode As String) As Object
    If Not m_sess Is Nothing Then
        On Error Resume Next
        ResetSAP m_sess
        m_sess.findById("wnd[0]/tbar[0]/okcd").Text = "/n" & sTCode
        m_sess.findById("wnd[0]").sendVKey 0
        If Err.Number = 0 Then
            On Error GoTo 0
            WaitSAPIdle m_sess
            Set UseSAP = m_sess
            Exit Function
        End If
        LogMsg "SAP: could not reuse the session (" & Err.Description & ") - opening a new one"
        On Error GoTo 0
        Set m_sess = Nothing
    End If
    Set m_sess = GetSAPSession(sTCode)
    Set UseSAP = m_sess
End Function

' Close any popup left open (e.g. after a failed step) so the next /n works
Private Sub ResetSAP(ByVal sess As Object)
    Dim k As Long
    If sess Is Nothing Then Exit Sub
    On Error Resume Next
    For k = 1 To 3
        If sess.Children.Count <= 1 Then Exit Sub
        sess.findById("wnd[" & (sess.Children.Count - 1) & "]").sendVKey 12   ' F12 = cancel
        WaitSAPIdle sess, 0.1
    Next k
End Sub

' End of run: close the window we opened (never the user's own one)
Private Sub EndSAP()
    If Not m_sess Is Nothing Then
        If m_sessOwned Then CloseSAPSession m_sess
    End If
    Set m_sess = Nothing
End Sub

' Wait until SAP has finished the last step instead of pausing a fixed time
Private Sub WaitSAPIdle(ByVal sess As Object, Optional ByVal minSecs As Single = 0.2)
    Dim i As Long, isBusy As Boolean
    PauseSeconds minSecs
    On Error Resume Next
    For i = 1 To SAP_BUSY_SECS * 10
        isBusy = False
        isBusy = sess.Busy
        If Err.Number <> 0 Then Err.Clear: isBusy = False
        If Not isBusy Then Exit Sub
        Sleep 100
        DoEvents
    Next i
End Sub

Private Sub CloseSAPSession(ByRef oSess As Object)
    On Error Resume Next
    If Not oSess Is Nothing Then
        oSess.findById("wnd[0]/tbar[0]/okcd").Text = "/i"
        oSess.findById("wnd[0]").sendVKey 0
    End If
    Set oSess = Nothing
End Sub

' Log (and clear) an error raised by the previous SAP scripting line
Private Sub SapErr(ByVal stepName As String)
    If Err.Number <> 0 Then
        LogMsg "  SAP step '" & stepName & "' error " & Err.Number & ": " & Err.Description
        Err.Clear
    End If
End Sub

' ============================================================================
'   FILE HELPERS
' ============================================================================

Private Function Fso() As Object
    If m_fso Is Nothing Then Set m_fso = CreateObject("Scripting.FileSystemObject")
    Set Fso = m_fso
End Function

Private Function NewExportPath(ByVal prefix As String) As String
    Dim p As String, k As Long
    If Not Fso.FolderExists(SAP_EXPORT_DIR) Then CreateFolderPath SAP_EXPORT_DIR
    p = SAP_EXPORT_DIR & "sap_" & prefix & "_" & Format$(Now, "yyyymmdd_hhnnss") & ".csv"
    Do While Fso.FileExists(p)                        ' SAP fails silently if the file exists
        k = k + 1
        p = SAP_EXPORT_DIR & "sap_" & prefix & "_" & Format$(Now, "yyyymmdd_hhnnss") & "_v" & k & ".csv"
    Loop
    NewExportPath = p
End Function

' Hand the SAP export to the background upload as-is (no conversion in VBA).
' Waits only until the file has stopped growing; robocopy retries by itself if it is still locked.
Private Function QueueRawFile(ByVal sapFile As String, ByVal feed As String, _
                              Optional ByVal tag As String = "") As String
    Dim boxDir As String, fileName As String, sz As Double, prev As Double, i As Long, t As Double
    t = Timer
    For i = 1 To 120                                   ' up to 60s for SAP to finish writing
        If Fso.FileExists(sapFile) Then
            sz = Fso.GetFile(sapFile).Size
            If sz > 0 And sz = prev Then Exit For
            prev = sz
        End If
        PauseSeconds 0.5
    Next i
    If sz = 0 Then QueueRawFile = "FAILED - SAP export file is missing or empty": Exit Function

    boxDir = OutboxRoot() & feed & "\"
    If Not Fso.FolderExists(boxDir) Then CreateFolderPath boxDir
    Do
        m_seq = m_seq + 1
        ' e.g. ke24_raw_Current_009_2026_20260924_195624_3.csv - the notebook reads kind/period/date from it
        fileName = feed & "_" & IIf(Len(tag) > 0, tag & "_", "") & Format$(Now, "yyyymmdd_hhnnss") & "_" & m_seq & ".csv"
    Loop While Fso.FileExists(boxDir & fileName)

    On Error Resume Next
    For i = 1 To 10                                    ' a move is instant on the same drive
        Err.Clear
        Fso.MoveFile sapFile, boxDir & fileName
        If Err.Number = 0 Then Exit For
        PauseSeconds 0.5
    Next i
    If Err.Number <> 0 Then                            ' still held open: copy instead, tidy later
        Err.Clear
        Fso.CopyFile sapFile, boxDir & fileName, True
        If Err.Number <> 0 Then
            QueueRawFile = "FAILED - could not queue the SAP file (" & Err.Description & ")"
            Exit Function
        End If
        DeleteFileRetry sapFile
    End If
    On Error GoTo 0

    m_batch.Add feed & "/" & fileName & PIPE & Fso.GetFile(boxDir & fileName).Size
    StartUpload feed, fileName
    LogStep "queue raw file", t
    QueueRawFile = "OK - " & Format$(Fso.GetFile(boxDir & fileName).Size / 1048576, "0.0") & " MB sent"
End Function

' Wait (midnight-safe) only until SAP has created the file - release is checked later
Private Function WaitForFileCreated(ByVal filePath As String, ByVal timeoutSecs As Long) As Boolean
    Dim i As Long
    For i = 1 To timeoutSecs * 4
        If Fso.FileExists(filePath) Then WaitForFileCreated = True: Exit Function
        PauseSeconds 0.25
    Next i
End Function

' UTF-8 with BOM, one stream write
Private Sub WriteUtf8(ByVal filePath As String, ByVal payload As String)
    Dim stm As Object
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 2: stm.Charset = "UTF-8": stm.Open
    stm.WriteText payload
    stm.SaveToFile filePath, 2
    stm.Close
End Sub

Private Sub DeleteFileRetry(ByVal filePath As String)
    Dim k As Long
    For k = 1 To 5
        On Error Resume Next
        If Not Fso.FileExists(filePath) Then Exit Sub
        Fso.DeleteFile filePath, True
        If Err.Number = 0 Then Exit Sub
        Err.Clear
        On Error GoTo 0
        PauseSeconds 1
    Next k
    LogMsg "Could not delete " & filePath & " after 5 tries (harmless - delete it later)"
End Sub

Private Sub CreateFolderPath(ByVal folderPath As String)
    Dim parent As String
    If Right$(folderPath, 1) = "\" Then folderPath = Left$(folderPath, Len(folderPath) - 1)
    If Fso.FolderExists(folderPath) Then Exit Sub
    parent = Fso.GetParentFolderName(folderPath)
    If Len(parent) > 0 And Not Fso.FolderExists(parent) Then CreateFolderPath parent
    Fso.CreateFolder folderPath
End Sub

Private Function BrowseForFiles(ByVal sTitle As String, ByVal multi As Boolean) As Collection
    Dim fd As Object, i As Long
    Set BrowseForFiles = New Collection
    Set fd = Application.FileDialog(3)               ' msoFileDialogFilePicker
    With fd
        .title = sTitle
        .Filters.Clear
        .Filters.Add "Excel Files", "*.xlsx;*.xlsm;*.xls;*.xlsb"
        .AllowMultiSelect = multi
        If .Show = -1 Then
            For i = 1 To .SelectedItems.Count: BrowseForFiles.Add .SelectedItems(i): Next i
        End If
    End With
End Function

Private Sub LogMsg(ByVal msg As String)
    Dim ts As Object
    Debug.Print Format$(Now, "hh:nn:ss") & "  " & msg
    On Error Resume Next
    If Not Fso.FolderExists(SAP_EXPORT_DIR) Then CreateFolderPath SAP_EXPORT_DIR
    Set ts = Fso.OpenTextFile(SAP_EXPORT_DIR & LOG_FILE_NAME, 8, True)
    ts.WriteLine Format$(Now, "yyyy-mm-dd hh:nn:ss") & "  " & msg
    ts.Close
End Sub

' ============================================================================
'   VALUE HELPERS
' ============================================================================

' Midnight-safe pause: no Timer arithmetic, no CPU spin
Private Sub PauseSeconds(ByVal seconds As Single)
    Dim i As Long
    For i = 1 To CLng(seconds * 10)
        Sleep 100
        DoEvents
    Next i
End Sub

' SAP number -> Double. Handles thousands commas, spaces, "-" = 0, trailing minus.
Private Function SafeDbl(ByVal v As Variant) As Double
    Dim s As String
    If IsEmpty(v) Or IsNull(v) Or IsError(v) Then Exit Function
    If IsNumeric(v) Then SafeDbl = CDbl(v): Exit Function
    s = Replace(Replace(Trim$(CStr(v)), ",", ""), " ", "")
    If s = "-" Or s = "" Then Exit Function
    On Error Resume Next
    SafeDbl = CDbl(s)
    If Err.Number <> 0 Then SafeDbl = 0
End Function

' Seconds since a Timer value (safe across midnight)
Private Function SecondsSince(ByVal t As Double) As Double
    SecondsSince = Timer - t
    If SecondsSince < 0 Then SecondsSince = SecondsSince + 86400
End Function

' Log how long a step took, then restart the stopwatch
Private Sub LogStep(ByVal stepName As String, ByRef t As Double)
    LogMsg "  " & stepName & ": " & Format$(SecondsSince(t), "0.0") & "s"
    t = Timer
End Sub

' Locale-independent number text (always "." decimal, no separators)
Private Function NumStr(ByVal d As Double) As String
    NumStr = Trim$(Str$(d))
    If Left$(NumStr, 1) = "." Then NumStr = "0" & NumStr
    If Left$(NumStr, 2) = "-." Then NumStr = "-0" & Mid$(NumStr, 2)
End Function

Private Function IsoDate(ByVal d As Date) As String
    IsoDate = Format$(d, "yyyy-mm-dd")
End Function

' RFC-4180 minimal quoting for the pipe delimiter
Private Function CsvField(ByVal v As Variant) As String
    Dim s As String
    s = NzS(v)
    If InStr(s, PIPE) > 0 Or InStr(s, """") > 0 Or InStr(s, vbLf) > 0 Or InStr(s, vbCr) > 0 Then
        s = """" & Replace(Replace(Replace(s, vbCr, " "), vbLf, " "), """", """""") & """"
    End If
    CsvField = s
End Function

Private Function NzS(ByVal v As Variant) As String
    If IsEmpty(v) Or IsNull(v) Or IsError(v) Then NzS = "" Else NzS = CStr(v)
End Function

Private Function MapStr(ByRef arr As Variant, ByVal r As Long, ByVal colMap As Object, ByVal name As String) As String
    If colMap.Exists(name) Then MapStr = Trim$(NzS(arr(r, colMap(name))))
End Function

Private Function MapNum(ByRef arr As Variant, ByVal r As Long, ByVal colMap As Object, ByVal name As String) As String
    If colMap.Exists(name) Then MapNum = NumStr(SafeDbl(arr(r, colMap(name))))
End Function

Private Function PartsToClip(ByVal sParts As String) As String
    Dim p() As String, i As Long
    sParts = Replace(Replace(Replace(sParts, vbCrLf, ","), vbLf, ","), ";", ",")
    If Len(Trim$(sParts)) = 0 Then Exit Function
    p = Split(sParts, ",")
    For i = 0 To UBound(p)
        If Len(Trim$(p(i))) > 0 Then PartsToClip = PartsToClip & Trim$(p(i)) & vbCrLf
    Next i
End Function

Private Function ParsePeriod(ByVal s As String, ByRef p As Long, ByRef y As Long) As Boolean
    Dim parts() As String
    parts = Split(Trim$(s), "/")
    If UBound(parts) <> 1 Then Exit Function
    If Not IsNumeric(parts(0)) Or Not IsNumeric(parts(1)) Then Exit Function
    p = CLng(parts(0)): y = CLng(parts(1))
    ParsePeriod = (p >= 1 And p <= 12 And y >= 2000)
End Function

Private Function TryParseDateDMY(ByVal s As String, ByRef dt As Date) As Boolean
    Dim parts() As String
    s = Trim$(s)
    If InStr(s, "/") = 0 Then Exit Function
    parts = Split(s, "/")
    If UBound(parts) <> 2 Then Exit Function
    On Error Resume Next
    dt = DateSerial(CInt(parts(2)), CInt(parts(1)), CInt(parts(0)))
    TryParseDateDMY = (Err.Number = 0)
End Function

Private Function CleanHeader(ByVal s As String) As String
    s = Trim$(s)
    If Left$(s, 1) = "'" Then s = Mid$(s, 2)
    CleanHeader = Trim$(s)
End Function

Private Function FindPeriodCol(ByVal ws As Object, ByVal headerRow As Long, ByVal sTarget As String) As Long
    Dim c As Long, lastCol As Long
    lastCol = ws.Cells(headerRow, ws.Columns.Count).End(-4159).Column
    For c = 1 To lastCol
        If StrComp(CleanHeader(NzS(ws.Cells(headerRow, c).Value)), sTarget, vbTextCompare) = 0 Then FindPeriodCol = c: Exit Function
    Next c
End Function

Private Function LastFilledRowA(ByVal ws As Object, ByVal startRow As Long) As Long
    Dim r As Long
    r = startRow
    Do While Len(Trim$(NzS(ws.Cells(r, 1).Value))) > 0
        r = r + 1
    Loop
    LastFilledRowA = r - 1
End Function

' ============================================================================
'   P3381 DAILY DASHBOARD FEED  (runs after the Bradford upload is confirmed)
'   Port of P3381LakehouseFeed.bas v1.1 (Excel) with the Feed / Scope sheet
'   values fixed below. Same five SAP transactions, same recorded steps, same
'   raw files, scope, run_info and .done into lh_p3381_daily - the notebook
'   nb_ingest_p3381_sap cannot tell the two apart. To change the scope or a
'   setting, edit the constants / P3_Scope* functions here.
' ============================================================================

' Waits for a batch file that OneLake File Explorer has accepted, then a background
' robocopy loop gives up after ~10 minutes (see FinishBatch) - wait a little longer.
Private Function WaitForDailyUpload(ByVal batchFile As String, ByVal maxSecs As Long, _
                                    ByRef detail As String) As Boolean
    Dim i As Long, waited As Long, nLeft As Long, rel As Variant, localReady As String
    If Len(batchFile) = 0 Then
        detail = "Nothing was sent to " & FABRIC_LAKEHOUSE & " - no upload to wait for."
        WaitForDailyUpload = True
        Exit Function
    End If
    localReady = OutboxRoot() & "_ready\" & batchFile
    For i = 1 To maxSecs \ 2
        If Not Fso.FileExists(localReady) Then             ' robocopy /MOV: gone = in OneLake
            waited = (i - 1) * 2
            detail = "Lakehouse: " & batchFile & " confirmed in " & FABRIC_LAKEHOUSE & " at " & _
                     Format$(Now, "hh:nn") & " (waited " & waited & "s) - Bradford reports updating."
            LogMsg "Bradford upload confirmed: " & batchFile & " after " & waited & "s"
            WaitForDailyUpload = True
            Exit Function
        End If
        nLeft = 0
        If Not m_lastItems Is Nothing Then
            For Each rel In m_lastItems
                If Fso.FileExists(OutboxRoot() & Replace(Split(CStr(rel), PIPE)(0), "/", "\")) Then nLeft = nLeft + 1
            Next rel
        End If
        ShowStatus "Waiting for the Bradford files to reach the lakehouse - " & _
                   IIf(nLeft > 0, nLeft & " file(s) still uploading", "sending the batch file") & _
                   " (" & (i - 1) * 2 & "s)"
        PauseSeconds 2
    Next i
    detail = "Lakehouse: Bradford upload NOT confirmed after " & maxSecs \ 60 & " min - " & batchFile & _
             " is held back and re-sent with the next run (see " & UPLOAD_LOG_NAME & ")."
    LogMsg "Bradford upload not confirmed after " & maxSecs & "s - continuing with P3381"
End Function

' The P3381 feed. Returns the dialog lines; counts OK / failed sources.
Private Function P3_RunFeed(ByRef nOk As Long, ByRef nFail As Long) As String
    Dim landing As String, exportDir As String, files As Collection, src As Variant
    Dim asm() As String, crit() As String, both() As String, nAsm As Long, nCrit As Long, nBoth As Long
    Dim shipFrom As Date, shipTo As Date, listing As String, f As Variant, t As Double
    Dim out As String, st As String, secs As Long, logDetail As String

    On Error GoTo Fail
    landing = P3_LandingDir()
    If Not Fso.FolderExists(landing) Then
        nFail = nFail + 1
        P3_RunFeed = "FAILED  P3381 landing folder not found - nothing run:" & vbCrLf & "        " & landing & vbCrLf
        LogMsg "P3381: landing folder not found " & landing
        Exit Function
    End If
    exportDir = P3_EXPORT_DIR
    If Not Fso.FolderExists(exportDir) Then CreateFolderPath exportDir

    nAsm = P3_AssemblyList(asm)
    nCrit = P3_MaterialList(crit)
    nBoth = P3_Union(asm, nAsm, crit, nCrit, both)

    m_p3RunAt = Now
    m_p3Stamp = Format$(m_p3RunAt, "yyyymmdd_hhnnss")
    Set m_p3Status = CreateObject("Scripting.Dictionary")
    Set files = New Collection
    shipTo = Date
    shipFrom = Date - P3_SHIP_DAYS
    LogMsg "=== P3381 feed started (batch " & m_p3Stamp & ") ==="

    For Each src In Array("mb52", "zmelpa", "coois", "zsdu", "mb51")
        ShowStatus "P3381: running " & P3_Label(CStr(src)) & " ..."
        t = Timer
        P3_RunOne CStr(src), exportDir, landing, asm, nAsm, crit, nCrit, both, nBoth, shipFrom, shipTo, files
        secs = CLng(SecondsSince(t))
        st = m_p3Status(src)(0)
        If st = "FAILED" Then nFail = nFail + 1 Else nOk = nOk + 1
        out = out & IIf(st = "FAILED", "FAILED  ", "OK      ") & P3_Label(CStr(src)) & _
              IIf(st = "NODATA", " - no documents in the window", "") & _
              IIf(st = "FAILED", " - " & m_p3Status(src)(3), "") & " (" & secs & "s)" & vbCrLf
        logDetail = logDetail & "  " & P3_Label(CStr(src)) & ": " & st & " " & m_p3Status(src)(3) & " [" & secs & "s]" & vbCrLf
    Next src
    EndSAP                                               ' close the SAP window this run opened

    ' scope + run info, then the .done sentinel LAST (it lists the batch)
    P3_WriteScopeFiles landing, files
    P3_WriteRunInfo landing, shipFrom, shipTo, files
    For Each f In files
        listing = listing & CStr(f) & vbCrLf
    Next f
    WriteUtf8 landing & P3_PREFIX & "_batch_" & m_p3Stamp & ".done", listing
    LogMsg "P3381 batch " & m_p3Stamp & " sent (" & files.Count & " files)" & vbCrLf & logDetail

    out = out & "Batch p3381_batch_" & m_p3Stamp & " sent: " & nOk & " of 5 sources OK" & _
          IIf(nFail = 0, " - the dashboard updates in about 5 minutes.", _
                         " - failed sources show as not refreshed.") & vbCrLf
    P3_RunFeed = out
    Exit Function
Fail:
    nFail = nFail + 1
    LogMsg "P3381 feed error " & Err.Number & ": " & Err.Description
    P3_RunFeed = out & "FAILED  P3381 feed stopped - " & Err.Description & " (no .done sent)" & vbCrLf
    On Error Resume Next
    EndSAP
End Function

' One source: extract, copy the raw file into the landing folder, record status.
Private Sub P3_RunOne(ByVal src As String, ByVal exportDir As String, ByVal landing As String, _
                      ByRef asm() As String, ByVal nAsm As Long, ByRef crit() As String, ByVal nCrit As Long, _
                      ByRef both() As String, ByVal nBoth As Long, ByVal shipFrom As Date, ByVal shipTo As Date, _
                      ByVal files As Collection)
    Dim p As String, target As String, st As String, msgTxt As String
    On Error GoTo Fail
    Select Case src
        Case "mb52":   p = P3_ExtractMB52(both, nBoth, exportDir)
        Case "zmelpa": p = P3_ExtractZMELPA(crit, nCrit, exportDir)
        Case "coois":  p = P3_ExtractCOOIS(asm, nAsm, exportDir)
        Case "zsdu":   p = P3_ExtractZSDU(asm, nAsm, exportDir)
        Case "mb51":   p = P3_ExtractMB51(asm, nAsm, exportDir, shipFrom, shipTo)
    End Select
    If p = "*" Then                                      ' MB51: SAP found no documents
        st = "NODATA"
        msgTxt = "SAP found no documents in the window"
    Else
        target = P3_PREFIX & "_" & src & "_" & m_p3Stamp & ".txt"
        P3_CopyIntoLanding p, landing, target
        files.Add target
        If Not P3_KEEP_LOCAL Then DeleteFileRetry p
        st = "OK"
    End If
    m_p3Status(src) = Array(st, Now, target, msgTxt)
    Exit Sub
Fail:
    msgTxt = Replace(Err.Description, vbCrLf, " ")
    LogMsg "P3381 " & src & " error " & Err.Number & ": " & msgTxt
    m_p3Status(src) = Array("FAILED", Now, "", msgTxt)
    On Error Resume Next
    ResetSAP m_sess                                      ' close popups, back to a known screen
    P3_GoHome m_sess
End Sub

' Copy to a temp name, then rename - the final name only appears once the bytes are there.
Private Sub P3_CopyIntoLanding(ByVal srcPath As String, ByVal landing As String, ByVal target As String)
    Dim tmp As String
    tmp = landing & target & ".partial"
    If Fso.FileExists(tmp) Then Fso.DeleteFile tmp, True
    Fso.CopyFile srcPath, tmp, True
    If Fso.FileExists(landing & target) Then Fso.DeleteFile landing & target, True
    Fso.MoveFile tmp, landing & target
End Sub

' ---- SAP helpers for the P3381 blocks -----------------------------------
' One SAP window for the P3381 run (opened on the Easy Access menu, closed by EndSAP).
Private Function P3_Session() As Object
    Dim probe As String
    If Not m_sess Is Nothing Then
        On Error Resume Next
        probe = CStr(m_sess.Info.SessionNumber)
        If Err.Number = 0 Then
            On Error GoTo 0
            Set P3_Session = m_sess
            Exit Function
        End If
        On Error GoTo 0
        Set m_sess = Nothing
    End If
    Set m_sess = GetSAPSession("SESSION_MANAGER")
    If m_sess Is Nothing Then
        Err.Raise vbObjectError + 9101, "P3381", "SAP GUI is not running or not logged on."
    End If
    Set P3_Session = m_sess
End Function

Private Sub P3_GoHome(ByVal sess As Object)
    If sess Is Nothing Then Exit Sub
    On Error Resume Next
    sess.findById("wnd[0]/tbar[0]/okcd").Text = "/n"
    sess.findById("wnd[0]").sendVKey 0
    WaitSAPIdle sess
    On Error GoTo 0
End Sub

Private Sub P3_CheckSapStatus(ByVal sess As Object, ByVal where As String)
    Dim mt As String, txt As String
    WaitSAPIdle sess
    On Error Resume Next
    mt = CStr(sess.findById("wnd[0]/sbar").MessageType)
    txt = Trim$(CStr(sess.findById("wnd[0]/sbar").Text))
    On Error GoTo 0
    If mt = "E" Or mt = "A" Or mt = "X" Then
        Err.Raise vbObjectError + 9110, where, "SAP refused the selection: " & txt
    End If
    If Len(txt) > 0 Then
        If InStr(1, txt, "no data", vbTextCompare) > 0 Or InStr(1, txt, "No entries", vbTextCompare) > 0 _
        Or InStr(1, txt, "no stock", vbTextCompare) > 0 Or InStr(1, txt, "does not exist", vbTextCompare) > 0 Then
            Err.Raise vbObjectError + 9111, where, "SAP returned nothing: " & txt
        End If
    End If
End Sub

Private Function P3_NoDocuments(ByVal sess As Object) As Boolean
    Dim txt As String
    WaitSAPIdle sess
    On Error Resume Next
    txt = LCase$(Trim$(CStr(sess.findById("wnd[0]/sbar").Text)))
    On Error GoTo 0
    If Len(txt) = 0 Then Exit Function
    P3_NoDocuments = (InStr(txt, "no material doc") > 0 Or InStr(txt, "no data") > 0 Or _
                      InStr(txt, "no entries") > 0 Or (Left$(txt, 3) = "no " And InStr(txt, "found") > 0))
End Function

' ---------------------------------------------------------------- MB52 ------
Private Function P3_ExtractMB52(ByRef mats() As String, ByVal nMat As Long, ByVal exportDir As String) As String
    Dim sess As Object, fileName As String, fullPath As String

    fileName = P3_UniqueExportName(exportDir, "P3_MB52_" & Format(Now, "yyyymmdd"), ".csv")
    fullPath = exportDir & fileName
    If Not P3_ListToClipboard(mats, nMat) Then Err.Raise vbObjectError + 9201, "MB52", "Could not place the material list on the clipboard."

    Set sess = P3_Session()
    P3_GoHome sess

    ' ---- recorded block (MB52_Download_Projecttracker.vbs) -----------------
    On Error Resume Next   ' cosmetic only: pane sizing fails on some screens
    sess.findById("wnd[0]").resizeWorkingPane 88, 34, False
    sess.findById("wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell").setColSize 1, 47
    sess.findById("wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell").setColSize 2, 52
    On Error GoTo 0

    sess.findById("wnd[0]/tbar[0]/okcd").Text = "MB52"
    sess.findById("wnd[0]").sendVKey 0
    P3_CheckSapStatus sess, "MB52 (start)"                                  ' [ADDED]
    sess.findById("wnd[0]/usr/btn%_MATNR_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/usr/tabsTAB_STRIP/tabpSIVA/ssubSCREEN_HEADER:SAPLALDB:3010/tblSAPLALDBSINGLE/ctxtRSCSEL_255-SLOW_I[1,0]").Text = ""
    sess.findById("wnd[1]/tbar[0]/btn[24]").press          ' upload from clipboard
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/ctxtWERKS-LOW").Text = P3_PLANT      ' fixed value (Feed sheet)
    sess.findById("wnd[0]/usr/ctxtLGORT-LOW").Text = P3_SLOC       ' fixed value (Feed sheet)
    sess.findById("wnd[0]/usr/ctxtLGORT-LOW").SetFocus
    sess.findById("wnd[0]/usr/ctxtLGORT-LOW").caretPosition = 4
    sess.findById("wnd[0]/usr/btn%_CHARG_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_MATART_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_EKGRUP_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/chkPA_SOND").Selected = True
    sess.findById("wnd[0]/usr/chkPA_SOND").SetFocus
    sess.findById("wnd[0]").sendVKey 2
    sess.findById("wnd[0]/usr/btn%_SO_SOBKZ_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/chkNOZERO").Selected = False
    sess.findById("wnd[0]/usr/radPA_HSQ").SetFocus
    sess.findById("wnd[0]/usr/radPA_HSQ").Select
    sess.findById("wnd[0]/usr/radPA_FLT").SetFocus
    sess.findById("wnd[0]/usr/radPA_FLT").Select
    sess.findById("wnd[0]/usr/ctxtP_VARI").Text = P3_MB52_VARIANT   ' fixed value (Feed sheet)
    sess.findById("wnd[0]/usr/ctxtP_VARI").SetFocus
    sess.findById("wnd[0]/usr/ctxtP_VARI").caretPosition = 12
    sess.findById("wnd[0]/tbar[1]/btn[8]").press
    P3_CheckSapStatus sess, "MB52 (execute)"                               ' [ADDED]
    sess.findById("wnd[0]/tbar[1]/btn[45]").press
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").Select
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").SetFocus
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    sess.findById("wnd[1]/usr/ctxtDY_PATH").Text = exportDir        ' fixed value (Feed sheet)
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").Text = fileName     ' version-safe name
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = Len(fileName)
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    ' ---- end recorded block ------------------------------------------------

    If Not P3_WaitForFile(fullPath, P3_EXPORT_WAIT_SEC) Then
        Err.Raise vbObjectError + 9202, "MB52", "SAP did not finish writing " & fileName & " within " & P3_EXPORT_WAIT_SEC & " seconds."
    End If
    P3_ExtractMB52 = fullPath
End Function

' ------------------------------------------------------- ZMELPA03_KIB -------
' Always pulled DAILY from today for the horizon (P_PERIOD counts days when
' X_DAY is ticked) - the dashboard works in calendar days.
Private Function P3_ExtractZMELPA(ByRef comps() As String, ByVal nComp As Long, ByVal exportDir As String) As String
    Dim sess As Object, fileName As String, fullPath As String

    fileName = P3_UniqueExportName(exportDir, "P3_ZMELPA_" & Format(Now, "yyyymmdd"), ".csv")
    fullPath = exportDir & fileName
    If Not P3_ListToClipboard(comps, nComp) Then Err.Raise vbObjectError + 9203, "ZMELPA03_KIB", "Could not place the component list on the clipboard."

    Set sess = P3_Session()
    P3_GoHome sess

    ' ---- recorded block (ZMELPA03_KIB_Projecttracker.vbs) ------------------
    sess.findById("wnd[0]").maximize
    On Error Resume Next   ' cosmetic only
    sess.findById("wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell").setColSize 1, 47
    sess.findById("wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell").setColSize 2, 52
    On Error GoTo 0

    sess.findById("wnd[0]/tbar[0]/okcd").Text = "ZMELPA03_KIB"
    sess.findById("wnd[0]").sendVKey 0
    P3_CheckSapStatus sess, "ZMELPA03_KIB (start)"                         ' [ADDED]
    sess.findById("wnd[0]/usr/ctxtS_LIFNR-LOW").Text = "*"
    sess.findById("wnd[0]/usr/ctxtS_LIFNR-LOW").SetFocus
    sess.findById("wnd[0]/usr/ctxtS_LIFNR-LOW").caretPosition = 1
    sess.findById("wnd[0]/usr/btn%_S_WEDAT_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/ctxtS_WERKS-LOW").Text = P3_PLANT     ' fixed value (Feed sheet)
    sess.findById("wnd[0]/usr/ctxtS_WERKS-LOW").SetFocus
    sess.findById("wnd[0]/usr/ctxtS_WERKS-LOW").caretPosition = 4
    sess.findById("wnd[0]/usr/btn%_S_SPART_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_S_MTART_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_S_DISPO_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_S_MATNR_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[24]").press          ' upload from clipboard
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/ctxtS_MATNR-LOW").Text = comps(1)
    sess.findById("wnd[0]/usr/ctxtS_MATNR-LOW").SetFocus
    sess.findById("wnd[0]/usr/ctxtS_MATNR-LOW").caretPosition = Len(comps(1))
    sess.findById("wnd[0]/usr/btn%_S_MATKL_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_S_LIFNR_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/usr/tabsTAB_STRIP/tabpSIVA/ssubSCREEN_HEADER:SAPLALDB:3010/tblSAPLALDBSINGLE/ctxtRSCSEL_255-SLOW_I[1,0]").Text = "*"
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_S_EKGRP_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/radX_DAY").Select                                     ' fixed value (Feed sheet) (always daily)
    sess.findById("wnd[0]/usr/chkX_NOLEER").Selected = False
    sess.findById("wnd[0]/usr/chkC_LIFNR").Selected = True
    sess.findById("wnd[0]/usr/chkC_GRDAT").Selected = True
    sess.findById("wnd[0]/usr/chkC_SA").Selected = True
    sess.findById("wnd[0]/usr/ctxtP_START").Text = Format(Date, "dd.mm.yyyy")       ' fixed value (Feed sheet) (today)
    sess.findById("wnd[0]/usr/txtP_PERIOD").Text = CStr(P3_HORIZON_DAYS)           ' fixed value (Feed sheet) (days)
    sess.findById("wnd[0]/usr/chkC_SA").SetFocus
    sess.findById("wnd[0]/tbar[1]/btn[8]").press
    P3_CheckSapStatus sess, "ZMELPA03_KIB (execute)"                       ' [ADDED]
    sess.findById("wnd[0]/usr/cntlDATEN/shellcont/shell").pressToolbarContextButton "&MB_EXPORT"
    sess.findById("wnd[0]/usr/cntlDATEN/shellcont/shell").selectContextMenuItem "&PC"
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").Select
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").SetFocus
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    sess.findById("wnd[1]/usr/ctxtDY_PATH").Text = exportDir         ' fixed value (Feed sheet)
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").Text = fileName      ' version-safe name
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = Len(fileName)
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    ' ---- end recorded block ------------------------------------------------

    If Not P3_WaitForFile(fullPath, P3_EXPORT_WAIT_SEC) Then
        Err.Raise vbObjectError + 9204, "ZMELPA03_KIB", "SAP did not finish writing " & fileName & " within " & P3_EXPORT_WAIT_SEC & " seconds."
    End If
    P3_ExtractZMELPA = fullPath
End Function

' --------------------------------------------------------------- COOIS ------
Private Function P3_ExtractCOOIS(ByRef mats() As String, ByVal nMat As Long, ByVal exportDir As String) As String
    Dim sess As Object, fileName As String, fullPath As String

    fileName = P3_UniqueExportName(exportDir, "P3_COOIS_" & Format(Now, "yyyymmdd"), ".csv")
    fullPath = exportDir & fileName
    If Not P3_ListToClipboard(mats, nMat) Then Err.Raise vbObjectError + 9205, "COOIS", "Could not place the material list on the clipboard."

    Set sess = P3_Session()
    P3_GoHome sess

    ' ---- recorded block (COOIS_OrderDL2.vbs) -------------------------------
    On Error Resume Next   ' cosmetic only
    sess.findById("wnd[0]").resizeWorkingPane 88, 34, False
    On Error GoTo 0

    sess.findById("wnd[0]/tbar[0]/okcd").Text = "COOIS"
    sess.findById("wnd[0]").sendVKey 0
    P3_CheckSapStatus sess, "COOIS (start)"                                ' [ADDED]
    sess.findById("wnd[0]/usr/ssub%_SUBSCREEN_TOPBLOCK:PPIO_ENTRY:1100/ctxtPPIO_ENTRY_SC1100-ALV_VARIANT").Text = P3_COOIS_VARIANT   ' fixed value (Feed sheet)
    sess.findById("wnd[0]/usr/ssub%_SUBSCREEN_TOPBLOCK:PPIO_ENTRY:1100/chkPPIO_ENTRY_SC1100-SELECT_PLANNEDORDS").SetFocus
    sess.findById("wnd[0]/usr/ssub%_SUBSCREEN_TOPBLOCK:PPIO_ENTRY:1100/chkPPIO_ENTRY_SC1100-SELECT_PLANNEDORDS").Selected = True
    sess.findById("wnd[0]/usr/tabsTABSTRIP_SELBLOCK/tabpSEL_00/ssub%_SUBSCREEN_SELBLOCK:PPIO_ENTRY:1200/btn%_S_MATNR_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[24]").press          ' upload from clipboard
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/tabsTABSTRIP_SELBLOCK/tabpSEL_00/ssub%_SUBSCREEN_SELBLOCK:PPIO_ENTRY:1200/chkP_KZ_E1").Selected = True
    sess.findById("wnd[0]/usr/tabsTABSTRIP_SELBLOCK/tabpSEL_00/ssub%_SUBSCREEN_SELBLOCK:PPIO_ENTRY:1200/chkP_KZ_E2").Selected = True
    sess.findById("wnd[0]/usr/tabsTABSTRIP_SELBLOCK/tabpSEL_00/ssub%_SUBSCREEN_SELBLOCK:PPIO_ENTRY:1200/ctxtS_WERKS-LOW").Text = P3_PLANT    ' fixed value (Feed sheet) (was "6000")
    sess.findById("wnd[0]/usr/tabsTABSTRIP_SELBLOCK/tabpSEL_00/ssub%_SUBSCREEN_SELBLOCK:PPIO_ENTRY:1200/ctxtS_PWERK-LOW").Text = P3_PLANT    ' fixed value (Feed sheet) (was "6000")
    sess.findById("wnd[0]/usr/tabsTABSTRIP_SELBLOCK/tabpSEL_00/ssub%_SUBSCREEN_SELBLOCK:PPIO_ENTRY:1200/ctxtP_SYST1").Text = "DLV"
    sess.findById("wnd[0]/usr/tabsTABSTRIP_SELBLOCK/tabpSEL_00/ssub%_SUBSCREEN_SELBLOCK:PPIO_ENTRY:1200/ctxtP_SYST2").Text = "TECO"
    sess.findById("wnd[0]/usr/tabsTABSTRIP_SELBLOCK/tabpSEL_00/ssub%_SUBSCREEN_SELBLOCK:PPIO_ENTRY:1200/chkP_KZ_E2").SetFocus
    sess.findById("wnd[0]/tbar[1]/btn[8]").press
    P3_CheckSapStatus sess, "COOIS (execute)"                              ' [ADDED]
    sess.findById("wnd[0]/usr/cntlCUSTOM/shellcont/shell/shellcont/shell").pressToolbarButton "&NAVIGATION_PROFILE_TOOLBAR_EXPAND"
    sess.findById("wnd[0]/usr/cntlCUSTOM/shellcont/shell/shellcont/shell").pressToolbarContextButton "&MB_EXPORT"
    sess.findById("wnd[0]/usr/cntlCUSTOM/shellcont/shell/shellcont/shell").selectContextMenuItem "&PC"
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").Select
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").SetFocus
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    sess.findById("wnd[1]/usr/ctxtDY_PATH").Text = exportDir        ' fixed value (Feed sheet)
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").Text = fileName     ' version-safe name
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = Len(fileName)
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    ' ---- end recorded block ------------------------------------------------

    If Not P3_WaitForFile(fullPath, P3_EXPORT_WAIT_SEC) Then
        Err.Raise vbObjectError + 9206, "COOIS", "SAP did not finish writing " & fileName & " within " & P3_EXPORT_WAIT_SEC & " seconds."
    End If
    P3_ExtractCOOIS = fullPath
End Function

' ------------------------------------------------------ ZSDU106897 EDI ------
Private Function P3_ExtractZSDU(ByRef mats() As String, ByVal nMat As Long, ByVal exportDir As String) As String
    Dim sess As Object, fileName As String, fullPath As String

    fileName = P3_UniqueExportName(exportDir, "P3_ZSDU_" & Format(Now, "yyyymmdd"), ".csv")
    fullPath = exportDir & fileName
    If Not P3_ListToClipboard(mats, nMat) Then Err.Raise vbObjectError + 9207, "ZSDU106897", "Could not place the material list on the clipboard."

    Set sess = P3_Session()
    P3_GoHome sess

    ' ---- recorded block (ZSDU106897.vbs) -----------------------------------
    sess.findById("wnd[0]").maximize
    sess.findById("wnd[0]/tbar[0]/okcd").Text = "ZSDU106897"
    sess.findById("wnd[0]").sendVKey 0
    P3_CheckSapStatus sess, "ZSDU106897 (start)"                           ' [ADDED]
    sess.findById("wnd[0]/usr/ctxtS_VKORG-LOW").Text = P3_VKORG     ' fixed value (Feed sheet)
    sess.findById("wnd[0]/usr/ctxtS_VKORG-LOW").caretPosition = 4
    sess.findById("wnd[0]/usr/ctxtP_VARID").Text = P3_ZSDU_VARID   ' fixed value (Feed sheet)
    sess.findById("wnd[0]/usr/btn%_S_MATNR_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[24]").press          ' upload from clipboard
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/radR_RTPALV").Select
    sess.findById("wnd[0]/usr/radR_BKTDAY").Select                    ' fixed value (Feed sheet) (always daily)
    sess.findById("wnd[0]/usr/radR_DTCOM").Select
    sess.findById("wnd[0]/usr/radR_DTCOM").SetFocus
    sess.findById("wnd[0]/tbar[1]/btn[8]").press
    P3_CheckSapStatus sess, "ZSDU106897 (execute)"                         ' [ADDED]
    sess.findById("wnd[0]/usr/cntlDATEN/shellcont/shell").pressToolbarContextButton "&MB_EXPORT"
    sess.findById("wnd[0]/usr/cntlDATEN/shellcont/shell").selectContextMenuItem "&PC"
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").Select
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").SetFocus
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    sess.findById("wnd[1]/usr/ctxtDY_PATH").Text = exportDir         ' [ADDED] front-page input
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").Text = fileName      ' version-safe name
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = Len(fileName)
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    ' ---- end recorded block ------------------------------------------------

    If Not P3_WaitForFile(fullPath, P3_EXPORT_WAIT_SEC) Then
        Err.Raise vbObjectError + 9208, "ZSDU106897", "SAP did not finish writing " & fileName & " within " & P3_EXPORT_WAIT_SEC & " seconds."
    End If
    P3_ExtractZSDU = fullPath
End Function

' ---------------------------------------------------------------- MB51 ------
' 101 / 102 (production output) and 601 / 602 (shipments) in one pull, for the
' assemblies, over the look-back window - the same selection the tracker's
' Output module uses. The notebook splits them by movement type.
' Returns "*" when SAP finds no documents - a valid, empty answer.
Private Function P3_ExtractMB51(ByRef mats() As String, ByVal nMat As Long, ByVal exportDir As String, _
                             ByVal d1 As Date, ByVal d2 As Date) As String
    Dim sess As Object, fileName As String, fullPath As String, mvts(1 To 4) As String

    mvts(1) = "101": mvts(2) = "102": mvts(3) = "601": mvts(4) = "602"
    fileName = P3_UniqueExportName(exportDir, "P3_MB51_" & Format(Now, "yyyymmdd"), ".csv")
    fullPath = exportDir & fileName
    If Not P3_ListToClipboard(mats, nMat) Then Err.Raise vbObjectError + 9209, "MB51", "Could not place the material list on the clipboard."

    Set sess = P3_Session()
    P3_GoHome sess                                                          ' [ADDED]

    ' ---- recorded block (MB51) ---------------------------------------------
    sess.findById("wnd[0]").maximize
    sess.findById("wnd[0]/tbar[0]/okcd").Text = "MB51"
    sess.findById("wnd[0]").sendVKey 0
    P3_CheckSapStatus sess, "MB51 (start)"                                 ' [ADDED]
    sess.findById("wnd[0]/usr/btn%_MATNR_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[24]").press          ' upload from clipboard (materials)
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/ctxtWERKS-LOW").Text = P3_PLANT                                       ' fixed value (Feed sheet)
    sess.findById("wnd[0]/usr/ctxtLGORT-LOW").Text = P3_MB51_SLOC   ' fixed value (Feed sheet) (blank = all)
    sess.findById("wnd[0]/usr/ctxtCHARG-LOW").SetFocus
    sess.findById("wnd[0]/usr/ctxtCHARG-LOW").caretPosition = 0
    sess.findById("wnd[0]/usr/btn%_CHARG_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_LIFNR_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_KUNNR_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    If Not P3_ListToClipboard(mvts, 4) Then                                ' [ADDED] movement types
        Err.Raise vbObjectError + 9210, "MB51", "Could not place the movement types on the clipboard."
    End If
    sess.findById("wnd[0]/usr/btn%_BWART_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[24]").press          ' [ADDED] upload movement types
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_SOBKZ_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_AUFNR_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_KDAUF_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_KOSTL_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/btn%_MAT_KDAU_%_APP_%-VALU_PUSH").press
    sess.findById("wnd[1]/tbar[0]/btn[16]").press
    sess.findById("wnd[1]/tbar[0]/btn[8]").press
    sess.findById("wnd[0]/usr/ctxtBUDAT-LOW").Text = Format(d1, "dd.mm.yyyy")      ' fixed value (Feed sheet)
    sess.findById("wnd[0]/usr/ctxtBUDAT-HIGH").Text = Format(d2, "dd.mm.yyyy")     ' fixed value (Feed sheet)
    sess.findById("wnd[0]/usr/ctxtALV_DEF").Text = P3_MB51_VARIANT   ' fixed value (Feed sheet)
    sess.findById("wnd[0]/usr/radRFLAT_L").SetFocus
    On Error Resume Next
    sess.findById("wnd[0]/usr/radRFLAT_L").Select                       ' [ADDED] flat list, always
    On Error GoTo 0
    sess.findById("wnd[0]/tbar[1]/btn[8]").press
    If P3_NoDocuments(sess) Then P3_ExtractMB51 = "*": Exit Function          ' [ADDED] zero bookings is valid
    P3_CheckSapStatus sess, "MB51 (execute)"                               ' [ADDED]
    sess.findById("wnd[0]/mbar/menu[0]/menu[1]/menu[2]").Select
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").Select
    sess.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").SetFocus
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    sess.findById("wnd[1]/usr/ctxtDY_PATH").Text = exportDir          ' fixed value (Feed sheet)
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").Text = fileName       ' version-safe name
    sess.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = Len(fileName)
    sess.findById("wnd[1]/tbar[0]/btn[0]").press
    ' ---- end recorded block ------------------------------------------------

    If Not P3_WaitForFile(fullPath, P3_EXPORT_WAIT_SEC) Then
        Err.Raise vbObjectError + 9211, "MB51", "SAP did not finish writing " & fileName & " within " & P3_EXPORT_WAIT_SEC & " seconds."
    End If
    P3_ExtractMB51 = fullPath
End Function

' ---- batch files (pipe-delimited UTF-8 with BOM, written .partial then renamed) ----
Private Sub P3_WriteScopeFiles(ByVal landing As String, ByVal files As Collection)
    Dim nm As String, chain() As String, mats() As String
    chain = P3_ScopeChain()
    mats = P3_ScopeMaterials()
    nm = P3_PREFIX & "_scope_chain_" & m_p3Stamp & ".csv"
    P3_WriteLines landing & nm, "top_level|core|sw|top_line|core_line|sw_line|programme", chain
    files.Add nm
    nm = P3_PREFIX & "_scope_materials_" & m_p3Stamp & ".csv"
    P3_WriteLines landing & nm, "material|display_name|used_on|qty_per", mats
    files.Add nm
End Sub

Private Sub P3_WriteRunInfo(ByVal landing As String, ByVal shipFrom As Date, ByVal shipTo As Date, _
                            ByVal files As Collection)
    Dim kv As Variant, rows() As String, i As Long, n As Long, src As Variant, nm As String
    kv = Array("batch_id", m_p3Stamp, "run_at", Format$(m_p3RunAt, "yyyy-mm-dd\Thh:nn:ss"), _
               "run_date", Format$(Date, "yyyy-mm-dd"), "machine_user", Environ$("USERNAME"), _
               "mode", "SAP", "plant", P3_PLANT, "sloc", P3_SLOC, "vkorg", P3_VKORG, _
               "horizon_days", CStr(P3_HORIZON_DAYS), _
               "ship_from", Format$(shipFrom, "yyyy-mm-dd"), "ship_to", Format$(shipTo, "yyyy-mm-dd"), _
               "day_basis", P3_DAY_BASIS, "workbook", HostName(), _
               "mb51_mvts", P3_MB51_MVTS, "feed_version", P3_FEED_VERSION)
    ReDim rows(1 To (UBound(kv) + 1) \ 2 + m_p3Status.Count * 3)
    For i = 0 To UBound(kv) Step 2
        n = n + 1: rows(n) = kv(i) & "|" & P3_CsvField(kv(i + 1))
    Next i
    For Each src In m_p3Status.Keys
        n = n + 1: rows(n) = src & "_status|" & m_p3Status(src)(0)
        n = n + 1: rows(n) = src & "_at|" & Format$(m_p3Status(src)(1), "yyyy-mm-dd\Thh:nn:ss")
        n = n + 1: rows(n) = src & "_message|" & P3_CsvField(m_p3Status(src)(3))
    Next src
    nm = P3_PREFIX & "_run_info_" & m_p3Stamp & ".csv"
    P3_WriteLines landing & nm, "key|value", rows
    files.Add nm
End Sub

Private Sub P3_WriteLines(ByVal path As String, ByVal header As String, ByRef rows() As String)
    WriteUtf8 path & ".partial", header & vbCrLf & Join(rows, vbCrLf) & vbCrLf
    If Fso.FileExists(path) Then Fso.DeleteFile path, True
    Fso.MoveFile path & ".partial", path
End Sub

Private Function P3_CsvField(ByVal v As Variant) As String
    Dim s As String
    s = Replace(Replace(NzS(v), vbCr, " "), vbLf, " ")
    If InStr(s, "|") > 0 Or InStr(s, """") > 0 Then s = """" & Replace(s, """", """""") & """"
    P3_CsvField = s
End Function

' ---- fixed scope (Scope sheet of the P3381 feed workbook, 02/10/2026) ------
' Chain rows: top level | core | S&W | top line | core line | S&W line | programme
Private Function P3_ScopeChain() As String()
    Dim r(1 To 2) As String
    r(1) = "67809700022|67807105009|67801205006|BB P3381|BB Core OPF|Line 1|Volvo P3381"
    r(2) = "67809700023|67807105009|67801205006|BB P3381|BB Core OPF|Line 1|Volvo P3381"
    P3_ScopeChain = r
End Function

' Critical materials: material | display name | used on (assembly / assemblies) | qty per
Private Function P3_ScopeMaterials() As String()
    Dim r(1 To 11) As String
    r(1) = "67801006003|Turbine housing insulated|67809700022, 67809700023|1"
    r(2) = "67801016006|Turbine housing machined|67809700022, 67809700023|1"
    r(3) = "67901002507|Compressor housing assembly|67809700022|1"
    r(4) = "67901002508|Compressor housing assembly|67809700023|1"
    r(5) = "67001500056|Bearing housing & lever assembly|67807105009|1"
    r(6) = "67801231061|Turbine wheel casting|67801205006|1"
    r(7) = "67001095702|Actuator bracket machined|67809700022, 67809700023|1"
    r(8) = "67901232008|Compressor wheel, shot peened|67807105009|1"
    r(9) = "67801605003|Vane pack assembly, welded|67809700022, 67809700023|1"
    r(10) = "19801852500|Cup spring assembly BV80|67807105009|1"
    r(11) = "59001558060|Speed sensor clip assembly|67809700022, 67809700023|1"
    P3_ScopeMaterials = r
End Function

' Distinct assemblies, column by column (top levels, then cores, then S&W) - as the Excel feed.
Private Function P3_AssemblyList(ByRef out() As String) As Long
    Dim chain() As String, i As Long, j As Long, n As Long, s As String, seen As Object
    chain = P3_ScopeChain()
    Set seen = CreateObject("Scripting.Dictionary")
    ReDim out(1 To 3 * (UBound(chain) - LBound(chain) + 1))
    For j = 0 To 2
        For i = LBound(chain) To UBound(chain)
            s = Trim$(Split(chain(i), "|")(j))
            If Len(s) > 0 And Not seen.Exists(s) Then seen.Add s, 1: n = n + 1: out(n) = s
        Next i
    Next j
    ReDim Preserve out(1 To n)
    P3_AssemblyList = n
End Function

Private Function P3_MaterialList(ByRef out() As String) As Long
    Dim mats() As String, i As Long, n As Long, s As String, seen As Object
    mats = P3_ScopeMaterials()
    Set seen = CreateObject("Scripting.Dictionary")
    ReDim out(1 To UBound(mats) - LBound(mats) + 1)
    For i = LBound(mats) To UBound(mats)
        s = Trim$(Split(mats(i), "|")(0))
        If Len(s) > 0 And Not seen.Exists(s) Then seen.Add s, 1: n = n + 1: out(n) = s
    Next i
    ReDim Preserve out(1 To n)
    P3_MaterialList = n
End Function

Private Function P3_Union(ByRef a() As String, ByVal na As Long, ByRef b() As String, ByVal nb As Long, _
                          ByRef out() As String) As Long
    Dim seen As Object, i As Long, n As Long
    Set seen = CreateObject("Scripting.Dictionary")
    ReDim out(1 To na + nb)
    For i = 1 To na
        If Not seen.Exists(a(i)) Then seen.Add a(i), 1: n = n + 1: out(n) = a(i)
    Next i
    For i = 1 To nb
        If Not seen.Exists(b(i)) Then seen.Add b(i), 1: n = n + 1: out(n) = b(i)
    Next i
    ReDim Preserve out(1 To n)
    P3_Union = n
End Function

' ---- small P3381 helpers ----------------------------------------------------
Private Function P3_LandingDir() As String
    P3_LandingDir = Environ$("USERPROFILE") & "\OneLake - Microsoft\" & FABRIC_WORKSPACE & "\" & _
                    P3_LAKEHOUSE & ".Lakehouse\Files\landing\p3381_sap\"
End Function

Private Function P3_Label(ByVal src As String) As String
    Select Case src
        Case "mb52":   P3_Label = "MB52 stock"
        Case "zmelpa": P3_Label = "ZMELPA03_KIB inbound"
        Case "coois":  P3_Label = "COOIS orders"
        Case "zsdu":   P3_Label = "ZSDU106897 EDI demand"
        Case "mb51":   P3_Label = "MB51 output & shipments"
        Case Else:     P3_Label = src
    End Select
End Function

Private Function P3_UniqueExportName(ByVal dirPath As String, ByVal baseName As String, ByVal ext As String) As String
    Dim v As Long, nm As String
    nm = baseName & ext
    v = 1
    Do While Fso.FileExists(dirPath & nm)              ' SAP fails silently if the file exists
        nm = baseName & "_v" & v & ext
        v = v + 1
        If v > 500 Then Exit Do
    Loop
    P3_UniqueExportName = nm
End Function

' Wait (midnight-safe) for SAP to create the file and for its size to stop changing.
Private Function P3_WaitForFile(ByVal fullPath As String, ByVal secs As Long) As Boolean
    Dim i As Long, s1 As Double, s2 As Double
    For i = 1 To secs * 4
        If Fso.FileExists(fullPath) Then Exit For
        PauseSeconds 0.25
    Next i
    If Not Fso.FileExists(fullPath) Then Exit Function
    s2 = -1
    For i = 1 To secs
        On Error Resume Next
        s1 = Fso.GetFile(fullPath).Size
        On Error GoTo 0
        If s1 > 0 And s1 = s2 Then P3_WaitForFile = True: Exit Function
        s2 = s1
        PauseSeconds 1
    Next i
    P3_WaitForFile = (s1 > 0)
End Function

' One value per line - what the recorded "upload from clipboard" (btn[24]) reads.
Private Function P3_ListToClipboard(ByRef items() As String, ByVal n As Long) As Boolean
    Dim s As String, i As Long, oClip As Object
    For i = 1 To n
        s = s & items(i) & vbCrLf
    Next i
    If P3_ClipSetText(s) Then P3_ListToClipboard = True: Exit Function
    On Error Resume Next                                ' fallback: Forms DataObject
    Set oClip = CreateObject("New:{1C3B4210-F441-11CE-B9EA-00AA006B1A69}")
    oClip.SetText s
    oClip.PutInClipboard
    P3_ListToClipboard = (Err.Number = 0)
    On Error GoTo 0
End Function

Private Function P3_ClipSetText(ByVal s As String) As Boolean
#If VBA7 Then
    Dim hMem As LongPtr, p As LongPtr
#Else
    Dim hMem As Long, p As Long
#End If
    If Len(s) = 0 Then Exit Function
    On Error GoTo Fail
    If OpenClipboard(0) = 0 Then Exit Function
    EmptyClipboard
    hMem = GlobalAlloc(GMEM_MOVEABLE_ZEROINIT, (Len(s) + 1) * 2)
    If hMem <> 0 Then
        p = GlobalLock(hMem)
        If p <> 0 Then
            lstrcpyW p, StrPtr(s)
            GlobalUnlock hMem
            P3_ClipSetText = (SetClipboardData(CF_UNICODETEXT, hMem) <> 0)
        End If
    End If
    CloseClipboard
    Exit Function
Fail:
    On Error Resume Next
    CloseClipboard
    On Error GoTo 0
End Function

' Access status bar (SysCmd) or Excel status bar - late bound so the module compiles in both.
Private Sub ShowStatus(ByVal msg As String)
    Dim app As Object
    On Error Resume Next
    Set app = Application
    If Len(msg) = 0 Then
        app.SysCmd 5                                     ' acSysCmdClearStatus
        If Err.Number <> 0 Then Err.Clear: app.StatusBar = False
    Else
        app.SysCmd 4, msg                                ' acSysCmdSetStatus
        If Err.Number <> 0 Then Err.Clear: app.StatusBar = msg
    End If
    DoEvents
End Sub

Private Function HostName() As String
    Dim app As Object
    On Error Resume Next
    Set app = Application
    HostName = app.CurrentProject.Name                  ' Access
    If Len(HostName) = 0 Then HostName = app.ActiveWorkbook.Name
    If Len(HostName) = 0 Then HostName = "DailyRefresh"
End Function
