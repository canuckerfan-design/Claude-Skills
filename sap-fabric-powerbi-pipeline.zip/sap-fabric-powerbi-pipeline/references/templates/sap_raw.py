# ---- Raw SAP export converters (S_P99 inventory, MB52) -------------------------------
# Same rules as the old VBA ParseInventory / ParseMB52, run in Fabric instead of Access.
import re as _re

def decode_sap(raw):
    """SAP 'local file' exports are in the Windows code page (cp1252) unless they carry a BOM."""
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16")
    if raw[:3] == b"\xef\xbb\xbf":
        return raw[3:].decode("utf-8", errors="replace")
    return raw.decode("cp1252", errors="replace")

def _lines(text):
    return _re.split(r"\r\n|\n|\r", text)

def sap_num(v):
    """SAP number text -> plain number text: drop thousands commas, trailing minus to the front."""
    if v == "":
        return "0"
    v = v.replace(",", "")
    if v.endswith("-"):
        v = "-" + v[:-1]
    return "0" if v == "-" else v

# --- S_P99 "Material List: Prices and Inventory Values" --------------------------------
INV_HDR = ["Material", "Material Description", "Material Type", "Std price", "PerUnitPr.", "Crcy", "Per",
           "BUn", "Total stock", "Total val.", "Dv", "ValCl", "Val. Type", "Pr.", "Material Group"]
INV_OUT = ["Material", "Material_Description", "Material_Type", "Std_Price", "PerUnitPr", "Per", "BUn",
           "Total_Stock", "Total_Val", "Dv", "ValCl", "Val_Type", "Pr", "Material_Group"]
INV_SRC = [0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14]            # slot 5 "Crcy" not kept
INV_NUM = {3, 4, 7, 8}                                               # Std price, PerUnitPr, Total stock, Total val

def parse_inventory_raw(text):
    """-> list of rows in INV_OUT order (strings). Raises if the header row is missing."""
    col = None
    rows = []
    for line in _lines(text):
        f = line.split("\t")
        if col is None:
            found = {}
            for i, v in enumerate(f):
                v = v.strip(" ")
                if v in INV_HDR and v not in found:
                    found[v] = i
            if "Material" in found:
                col = [found.get(INV_HDR[s], -1) for s in INV_SRC]
            continue
        m = col[0]
        if m >= len(f) or f[m].strip(" ") == "":
            continue                                                  # blank / total lines
        out = []
        for c, k in enumerate(col):
            v = f[k].strip(" ") if 0 <= k < len(f) else ""
            out.append(sap_num(v) if c in INV_NUM else v)
        rows.append(out)
    if col is None:
        raise Exception("S_P99 header row (Material ... Material Group) not found in the raw export")
    return rows

# --- MB52 "Warehouse stocks of material" -----------------------------------------------
MB52_COLS = ["Material_ID", "Plnt", "SLoc", "S", "Valuation", "Stck_No", "Vendor", "SL", "BUn",
             "Unrestricted", "Crcy", "Value_Unrestricted", "Trans_Tfr", "Value_Trans_Tfr", "Qual_Insp",
             "Value_Qual_Insp", "Restricted", "Value_Restricted", "Blocked", "Value_Blocked",
             "Returns", "Value_Returns", "Vendor2"]
MB52_OFF = [0, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25]
MB52_NUM = {9, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21}

def parse_mb52_raw(text, snap_date):
    """-> list of [snap_date] + MB52_COLS rows. The material column is taken from the header,
    so SAP's per-unit total lines at the end (BOX, M, PC ...) are no longer loaded as materials."""
    rows, mcol = [], None
    for line in _lines(text):
        if mcol is None:
            if "Material" in line and "Plnt" in line:
                hdr = [h.strip(" ") for h in line.split("\t")]
                mcol = hdr.index("Material") if "Material" in hdr else -1
            continue
        tl = line.strip(" ")
        if not tl or tl.startswith("*") or "----------" in line:
            continue
        f = line.split("\t")
        if len(f) - 1 < 20:
            continue
        if mcol >= 0:
            off = mcol
        else:                                                         # header without a clean "Material" cell
            off = 0
            while off < len(f) and f[off].strip(" ") == "":
                off += 1
        mat = f[off].strip(" ") if off < len(f) else ""
        if not mat or "*" in mat:
            continue
        vals = []
        for c, d in enumerate(MB52_OFF):
            k = off + d
            v = f[k].strip(" ") if k < len(f) else ""
            vals.append(sap_num(v) if c in MB52_NUM else v)
        rows.append([snap_date] + vals)
    if mcol is None:
        raise Exception("MB52 header row (Material ... Plnt) not found in the raw export")
    return rows

# --- KE24 "Display Actual Line Items" ----------------------------------------------------
# (output name, SAP header alternatives - abbreviated | full), exactly as the old VBA ParseKE24
KE24_TXT = [("CoCd", "CoCd", "Company Code"), ("Crcy", "Crcy", "Currency"),
            ("Ref_Doc_No", "Ref.doc.no", "Reference document"), ("Posting_Currency", "Curr.", "Currency key"),
            ("Customer", "Customer"), ("Product", "Product"),
            ("MTyp", "MTyp", "Material Type"), ("BusA", "BusA", "Business Area")]
KE24_NUM = [("Sales_Qty", "Sales quan", "Sales quantity"), ("Sales_Gross", "Sales gross"),
            ("Raw_Material", "Raw mat.", "Raw material"), ("Foreign_Goods", "For. goods", "Foreign finish. good"),
            ("Semi_Finish_V", "S-finish V", "Semi-finish good VAR"), ("Fin_Goods_V", "F. goods V", "Finished goods VAR"),
            ("Other_Mat_Svc", "O. mat./se", "Other mat./services"), ("Labour", "Labour"),
            ("SU_Cost_V", "SU cost V", "Setup costs VAR"), ("TP_Cost_V", "TP costs V", "Unit costs VAR"),
            ("SDC_Prod", "SDC Prod.", "SDC Production"), ("Mat_OH", "Mat. OH", "Material OH"),
            ("Semi_Finish_F", "S-finish F", "Semi-finish good FIX"), ("SU_Cost_F", "SU cost F", "Setup costs FIX"),
            ("TP_Cost_F", "TP cost F", "Unit costs FIX"), ("Sales_OH", "Sales OH"),
            ("Admin_OH", "Admin. OH", "Administration OH"), ("RD_OH", "R&D OH"),
            ("RIsk_OH", "Risk OH"), ("All_Fix_OH", "All FIX OH", "Allocated FIX OH")]
KE24_TAIL = [("Base_UoM", "BUn", "Unit Sales quantity"), ("Currency_Type", "CTy", "Currency type"),
             ("Posting_Date", "Pstg date", "Posting date"), ("Prod_Hierarchy", "Prod.Hier.", "Product Hierarchy"),
             ("Profit_Centre", "Profit Ctr", "Profit Center"), ("Matl_Group", "Matl Group", "Material Group"),
             ("Record_Type", "RecordType", "Record Type", "Rec.Type"),
             ("Plan_Act_Indicator", "PA", "Plan/act", "Plan/Act. Indicator", "Version")]
KE24_EXCH = ("Exchange_Rate", "Exch.rate", "Exchange rate")
KE24_OUT = (["Run_Kind", "Period", "Fiscal_Year"] + [c[0] for c in KE24_TXT] + [c[0] for c in KE24_NUM]
            + [c[0] for c in KE24_TAIL] + ["Exchange_Rate", "Extract_Timestamp"])

def _find_col(headers, name):
    """Exact (case-insensitive) match first, then 'ends with' - as the VBA FindHeaderCol."""
    low = name.lower()
    for j, h in enumerate(headers):
        if h.lower() == low:
            return j
    for j, h in enumerate(headers):
        if len(h) > len(name) and h.lower().endswith(low):
            return j
    return -1

def _find_flex(headers, spec):
    for alt in spec[1:]:
        j = _find_col(headers, alt)
        if j >= 0:
            return j
    return -1

def _sap_date_iso(s):
    s = s.strip(" ")
    if len(s) >= 10 and s[2] == "." and s[5] == ".":
        return f"{s[6:10]}-{s[3:5]}-{s[0:2]}"
    return ""

def parse_ke24_raw(text, run_kind, period, year, stamp):
    """-> list of rows in KE24_OUT order. Raises if the header or essential columns are missing."""
    lines = _lines(text)
    hi = -1
    for i, l in enumerate(lines):
        low = l.lower()
        if "customer" in low and "product" in low and len(l.split("\t")) - 1 >= 3:
            hi = i
            break
    if hi < 0:
        raise Exception("KE24 header row (Customer ... Product) not found in the raw export")
    raw_h = lines[hi].split("\t")
    first = next((j for j, h in enumerate(raw_h) if h.strip(" ")), None)
    headers = [h.strip(" ") for h in raw_h[first:]]
    c_txt = [_find_flex(headers, s) for s in KE24_TXT]
    c_num = [_find_flex(headers, s) for s in KE24_NUM]
    c_tail = [_find_flex(headers, s) for s in KE24_TAIL]
    c_exch = _find_flex(headers, KE24_EXCH)
    essential = {"Customer": c_txt[4], "Product": c_txt[5], "Sales quantity": c_num[0], "Sales gross": c_num[1],
                 "Posting date": c_tail[2], "Raw material": c_num[2], "Material OH": c_num[11]}
    missing = [k for k, v in essential.items() if v < 0]
    if missing:
        raise Exception("KE24 columns not found: " + ", ".join(missing) + " | headers: " + " | ".join(headers))

    def cell(f, j):
        k = first + j
        return f[k].strip(" ") if j >= 0 and k < len(f) else ""

    rows = []
    for l in lines[hi + 1:]:
        if not l.strip(" "):
            continue
        f = l.split("\t")
        row = [run_kind, period, year]
        row += [cell(f, j) for j in c_txt]
        row += [sap_num(cell(f, j)) for j in c_num]
        row += [(_sap_date_iso(cell(f, j)) if n == 2 else cell(f, j)) for n, j in enumerate(c_tail)]
        row += [sap_num(cell(f, c_exch)), stamp]
        rows.append(row)
    return rows
