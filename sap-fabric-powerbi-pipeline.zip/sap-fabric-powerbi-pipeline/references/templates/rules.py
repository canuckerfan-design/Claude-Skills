# ---- Business rules ported 1:1 from the Access VBA (mod_Helpers, mod_KE24_Extract,
# ---- mod_FGStock_Extract, mod_ImportForecast). Pure Python so they are easy to test.

def strip_mat(s):
    s = (s or "").strip()
    while s.startswith("0") and len(s) > 1:
        s = s[1:]
    return s

def norm_mat(s):
    s = (s or "").strip()
    return s.zfill(18) if 0 < len(s) < 18 else s

def finance_mapping(cust, busa, material, ext_spares):
    """GetFinanceMapping -> (Finance_Name, Finance_Section)"""
    cust = cust or ""
    uc = cust.strip().upper()
    busa = (busa or "").strip()
    mat = (material or "").strip()
    if mat[:2] == "67":
        name = cust
        if "IVECO" in uc or "STELLANTIS" in uc: name = "Fiat / Iveco"
        if "FORD" in uc: name = "Ford Otosan" if busa == "0540" else "Ford PC"
        if "MAN" in uc: name = "MAN"
        if "SCANIA" in uc: name = "Scania"
        if "VOLVO" in uc: name = "Volvo"
        if "RENAULT" in uc: name = "Renault"
        return name, "BB"
    for key, nm in (("MAN", "MAN"), ("SCANIA", "Scania"), ("VOLVO", "Volvo"), ("RENAULT", "Renault")):
        if key in uc: return nm, "BB"
    if "IVECO" in uc or "STELLANTIS" in uc: return "Fiat / Iveco", "CV"
    if "FORD" in uc: return ("Ford Otosan", "CV") if busa == "0540" else ("Ford PC", "PC")
    if "IAM" in uc or "INTERCOMPANY" in uc: return "Kibo IAM", "IC"
    if "JLR" in uc:
        if strip_mat(mat) in ext_spares or norm_mat(mat) in ext_spares:
            return "External Spares", "IC"
        return "JLR", "PC"
    return (cust, "PC") if busa == "0520" else (cust, "CV")

def ke24_map_row(customer, product, busa, cust_lookup, ext_spares):
    """Customer name lookup + finance mapping + the two IC overrides."""
    cust = customer or ""
    name = cust_lookup.get(cust.strip().upper(), cust.strip())
    fin_name, section = finance_mapping(name, busa, product, ext_spares)
    sp = strip_mat(product)
    if sp[:2] == "67" and "INTERCO" in (fin_name or "").upper():
        section = "IC"
    if cust in ("6528", "4907") and sp[:1] == "3":
        section = "IC"
    return fin_name, section

def ke24_keep_row(customer, sales_qty, mtyp, sales_gross):
    if len((customer or "").strip()) == 0 and (sales_qty or 0) == 0:
        return False
    if (mtyp or "") == "VERP" and (sales_gross or 0) == 0:
        return False
    return True

def section_for_fg(cust, mat):
    """DeriveSectionForFG"""
    uc = (cust or "").strip().upper()
    if (mat or "")[:2] == "67": return "BB"
    if any(k in uc for k in ("MAN", "SCANIA", "VOLVO", "RENAULT")): return "BB"
    if any(k in uc for k in ("IAM", "KIBO", "INTERCO")): return "IC"
    if "JLR" in uc or "FORD PC" in uc: return "PC"
    return "CV"

def fg_customer(mat, custdata, ke24_current):
    """GetFGCustomer: tbl_CustomerData first, then KE24 'Current' rows, else blank"""
    name = (custdata.get(mat.upper()) or "").strip()
    if name:
        return name, section_for_fg(name, mat)
    if mat.upper() in ke24_current:
        return ke24_current[mat.upper()]
    return "", ""

def section_from_customer(cust):
    """DeriveSectionFromCustomer (forecast)"""
    uc = (cust or "").strip().upper()
    if any(k in uc for k in ("MAN", "SCANIA", "VOLVO", "RENAULT")): return "BB"
    if any(k in uc for k in ("IAM", "KIBO", "INTERCOMPANY", "EXTERNAL SPARES")): return "IC"
    if "JLR" in uc or "FORD PC" in uc: return "PC"
    return "CV"
