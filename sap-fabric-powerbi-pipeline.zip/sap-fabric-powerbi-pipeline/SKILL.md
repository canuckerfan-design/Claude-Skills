---
name: sap-fabric-powerbi-pipeline
description: |
  End-to-end playbook for moving an SAP GUI scripting + Access/Excel VBA + Power BI
  reporting process onto Microsoft Fabric with a one-button daily refresh: raw SAP
  export hand-over, OneLake File Explorer landing, ingest notebook, event-triggered
  pipeline, and Power BI models repointed to the lakehouse incl. OAuth 2.0 setup.
  Use when the user asks to "move my Access/VBA SAP reporting to Fabric",
  "automate my SAP extracts and Power BI refresh", "repoint Power BI from Access to
  the lakehouse", "chain a second SAP feed after the daily refresh", "generate a PBIP
  from code", or hits semantic model refresh errors (OAuth, default data connection),
  a Python notebook Delta write failure, CommitFailedError, or Direct Lake vs Import.
  Do NOT use for a single SAP macro (sap-vba-export), DAX measures
  (powerbi-dax) or trigger-only setup (fabric-event-ingestion).
metadata:
  category: automation
  icon: DataFlow
---

# SAP → Fabric Lakehouse → Power BI: one-button daily refresh

The condensed playbook from the Bradford migration (Access + VBA + 3 Power BI reports →
Fabric lakehouse, one daily button), extended with the second project on the same
pattern — the **P3381 Volvo launch daily dashboard** (5 SAP transactions → `.done`
sentinel → Python notebook → PBIP generated from code, chained after the Bradford
refresh). It records what worked and every pitfall hit, so the next project gets there
in a fraction of the steps.

**Result you are aiming for:** the user presses one button (or double-clicks a desktop
shortcut). SAP runs its recorded exports, the raw files go to the lakehouse in the
background, a Fabric pipeline loads the Delta tables and refreshes every Power BI report.
Nothing is stored in Access any more.

## When to Use
- Moving an Access/Excel-VBA SAP reporting process to a Fabric lakehouse
- "Automate my SAP extracts and Power BI refresh" / "one button for the morning reports"
- Landing raw SAP exports in a lakehouse through OneLake File Explorer
- A Fabric pipeline that should refresh semantic models after loading
- Repointing Power BI semantic models from Access to the lakehouse SQL endpoint
- Semantic model refresh errors: OAuth, "default data connection", gateway, 401, refresh-in-progress
- Deciding Direct Lake vs Import for migrated reports
- A Fabric **Python** (pandas + deltalake) notebook whose Delta write fails, or `CommitFailedError` from overlapping runs
- Chaining a second SAP feed after the daily refresh in the same Access runner
- Generating a Power BI project (PBIP: TMDL + PBIR) from Python

## When NOT to Use
- One stand-alone SAP export macro with no lakehouse — use sap-vba-export instead.
- Adapting a recorded SAP script line by line — use sap-script-discipline instead.
- Writing or installing DAX measures — use powerbi-dax instead.
- Only choosing/setting up a OneLake trigger — use fabric-event-ingestion instead.
- File format / naming rules for a CSV export on its own — use lakehouse-csv-exports instead.
- Excel/VBA speed tuning in general — use vba-performance instead.
- Deciding how to split VBA modules — use vba-project-structure instead.
- Making macro parameters editable on a front sheet — use guide-sheet-inputs instead.
- General project planning or effort estimates — use llm-assisted-workflow instead.

## How this skill relates to your other skills

This is the **orchestration** playbook. It points to the detail skills and, for this
architecture only, **overrides** two of their defaults:

| Skill | Use it for | Where THIS skill wins |
|---|---|---|
| sap-script-discipline | Keeping recorded SAP steps unchanged | — (still applies in full) |
| sap-vba-export | Filenames, export, file cleanup | **Supersedes Phase 3 (read data into an array).** In a lakehouse flow VBA does NOT parse SAP exports — hand the raw file over; Python in the notebook converts it |
| lakehouse-csv-exports | Atomic writes, pipe-delimited, ISO dates | **Refines the UTF-8-BOM default.** BOM is fine for data files read by Spark, but the batch manifest / trigger file must be plain ASCII **without a BOM** (the BOM broke the manifest) |
| fabric-event-ingestion | Event trigger vs schedule, cold-start trap | Adds the `_ready` batch-manifest pattern, the per-feed `.done` sentinel with a **Subject ends with `.done`** filter (File created fires once per file, not per batch), and duplicate-trigger handling |
| vba-project-structure | One .bas per tool | — (the runner is one .bas) |
| vba-performance | VBA speed rules | Mostly moot: no data processing left in VBA |
| guide-sheet-inputs | Front-page inputs for parameters | Optional, for the runner's constants |
| powerbi-dax | Measures | DAX stays untouched in a migration |
| llm-assisted-workflow | Estimates, project.md | Estimates below follow it |

## Bundled templates (Bradford-specific — swap names before use)

All in `references/templates/`. These are the **final, working** versions from the
project. They contain Bradford names you must replace: workspace `Bradford BI Analytics`,
lakehouse `Bradford_BI_LH`, plant `6000`, variants `/BFDINV`, `/BFD_LOCATIO`, KE24 variant
user `AKANNENKERIL`, operating concern `0020`, tcode `S_P99_41000062`, path
`C:\Reports\SAP_Runner.accdb`, table names `tbl_*`, and the customer/finance rules.

| File | What it is |
|---|---|
| [DailyRefresh.bas](references/templates/DailyRefresh.bas) | VBA runner **v2.3** (superset of v2.1) — all entry points, SAP session handling, raw hand-over, background upload, manifest, KE24 empty-period stop (v2.2), plus the **optional** chained second feed `RunDailyRefreshWithP3381` / `RunP3381Feed` (Phase 2b). The `P3_*` constants and `P3381_*` procedures are P3381-site-specific — delete that section if you don't chain a feed |
| [DailyRefresh.vbs](references/templates/DailyRefresh.vbs) | Desktop launcher (opens Access, runs `RunDailyRefresh` — or `RunDailyRefreshWithP3381` when chaining — quits) |
| [fabric_io_python_delta.py](references/templates/fabric_io_python_delta.py) | Python-notebook Delta I/O (Phase 3b): abfss writes with a notebook token, `Tables/dbo` detection, fixed Arrow schema from a `TABLES` contract dict (define/import it first), commit-conflict retry, `read_table` → None on first run |
| [nb_daily_ingest.ipynb](references/templates/nb_daily_ingest.ipynb) | Daily ingest notebook (converters + rules + idempotent writes + SQL endpoint sync) |
| [nb_load_history.ipynb](references/templates/nb_load_history.ipynb) | One-off history load with row-count check |
| [sap_raw.py](references/templates/sap_raw.py) | Raw SAP converters: S_P99 inventory, MB52, KE24 (already inlined in the notebook) |
| [rules.py](references/templates/rules.py) | Business rules as pure functions, for offline testing (inlined in the notebook) |
| [PowerQuery_Source_Swap.txt](references/templates/PowerQuery_Source_Swap.txt) | User instructions for the Power Query source swap. Its step 4 credential note is the short version — **Phase 4 below is the authoritative OAuth procedure** |

---

## The efficient path (do it in this order)

| # | Step | Est. time* |
|---|---|---|
| 1 | Discovery: collect everything in one request (Phase 0) | 30–60 min (mostly the user exporting files) |
| 2 | History load: convert Access exports, run `nb_load_history`, counts match | 1–2 h |
| 3 | Daily notebook: converters + rules, prove against raw files and history | 2–4 h |
| 4 | Semantic models: TMDL source swap, publish, **both** OAuth connections | 1–2 h |
| 5 | Pipeline + OneLake trigger | 30–60 min |
| 6 | VBA runner + launcher, first live run | 1–2 h |
| 7 | Side-by-side 2–3 mornings, cut-over | 15 min/day |

*Estimates per **llm-assisted-workflow**: about **1–1.5 working days** of build time with
good context (Bradford had 3 reports, 18 tables, 3 SAP feeds + 3 Excel imports), plus the
side-by-side days. Pipeline-side testing dominates — the time goes on Fabric clicks and
waiting for runs, not code. Build the lakehouse side **before** the macro: the macro is
the last thing to switch, so the old process keeps working until the new one is proven.

---

## Phase 0 — Discovery (gather once, up front)

Ask for everything in **one** message:

- [ ] All VBA modules (.bas / .txt) and form `.cls` files
- [ ] Each Access table exported as text **plus the field-name list per table** (text exports have no headers)
- [ ] Power BI measures as CSV export
- [ ] Each semantic model as **PBIP**: File > Save as > Power BI project; zip the `<name>.SemanticModel` folder. (A .pbix DataModel is XPress9-compressed and unreadable.)
- [ ] **One raw SAP export of each transaction** — copy `sap_*.csv` from `C:\Temp\SAPExports` *before* the old macro processes it
- [ ] **Ask early: should the lakehouse feed be standalone from the existing Excel analysis tool?** On P3381 the user pivoted mid-build ("Stop linking the Excel and the lakehouse") — the detailed Excel tracker stays for capacity studies, the lakehouse feed became a separate macro. Settle it in Phase 0, not halfway through

**Test before the first Fabric run:** build SAP-format test fixtures from the existing
workbook's data (UTF-16LE tab text, title block, SAP number formats, `*` subtotal and
special-stock rows, planned orders with a blank `Order`) and reconcile the notebook output
to the workbook end-to-end (P3381: 29/29 checks) before anything goes to Fabric.

Look for these traps while reading:
- [ ] Power Query steps that test text which may be blank (`Text.Contains`, `Text.Trim`) — nulls will break them
- [ ] Access Yes/No columns used as `TRUE()` in DAX → must stay boolean
- [ ] Whole-number columns → must stay whole numbers (bigint)
- [ ] Column names with spaces (not allowed in the lakehouse)
- [ ] Access-only tables (error/extract logs, staging) → replaced by `tbl_IngestLog`, not migrated
- [ ] Calculated columns or filters that silently relied on Access **archive retention** (e.g. snapshot kept 30 days + Mondays)
- [ ] Overlapping SAP extracts. Bradford's FG stock was just a filter of the S_P99 inventory snapshot (material type FERT + valuation class 0007 + non-zero stock) — verify against history, then drop the extra SAP run

What raw SAP "local file" exports look like (plan the converters for all of it):
cp1252 encoding, no BOM, CRLF, title rows above the header, leading tabs, thousands commas,
trailing-minus negatives (`1,234.50-`), DD.MM.YYYY dates, `*` subtotal lines, `----`
separator lines. **MB52 also appends per-unit total lines** (BOX, M, MM, PR, PAC, ROL, PC)
that the old VBA wrongly loaded as materials. (Some transactions export UTF-16LE tab text
instead — detect the BOM.)

**SAP data rules learned on P3381** (build them into the converters):
- **COOIS** — released vs planned is decided by the **order number** after stripping leading zeros (`0096…`, `002…`): `96*` = released, `2*` = planned. Planned orders often have a blank `Order` with the number in a separate `Planned order` column — read it, don't skip the row. Don't warn about a missing Planned-order column unless rows were actually dropped; report counts per type instead ("7 released, 255 planned")
- **MB51** — one pull for 101/102 (production output) + 601/602 (shipments). 101/102 count as output only on production orders `96*`/`66*`; MB51 already signs 102 negative, so output net = plain sum; 601 is shown negative, so shipments = −qty. Production day is either shift-based (06:00 boundary — needs the `Time` column) or posting date. The look-back must cover the chart window (≥12 days for 10 complete days)
- **MB52** — free stock = total − special-stock rows (e.g. `E`); skip `*` subtotal rows; unit from `BUn`
- **ZMELPA03_KIB / ZSDU106897** — pull daily buckets (`X_DAY` / `R_BKTDAY`); headers `dd.mm.yyyy`, plus a Past Due column and a beyond-horizon column
- Shipments and customer (EDI) demand apply only to **top-level customer assemblies**; internal sub-assemblies (e.g. core, shaft & wheel) get stock / plan / output only

## Phase 1 — Architecture (default)

```
SAP GUI (recorded steps unchanged)
  → raw export file
  → local outbox   C:\Temp\SAPExports\outbox\<feed>_raw\
  → background robocopy into the OneLake File Explorer mount
      %USERPROFILE%\OneLake - Microsoft\<Workspace>\<Lakehouse>.Lakehouse\Files\landing\<feed>\
  → batch manifest in landing\_ready\  (written LAST)
  → OneLake event trigger
  → pipeline: Notebook → If condition → semantic model refreshes
```

**Alternative for a single-feed lakehouse — the `.done` sentinel (P3381):** instead of a
`_ready` folder, write one `<feed>_batch_<stamp>.done` into the feed's own landing folder
(`Files/landing/<feed>/`), **last**, listing the batch files. Data files are written as
`.partial` then renamed. Either way the trigger must fire on the marker only (Phase 5).
Always give the user the **full** OneLake File Explorer path —
`%USERPROFILE%\OneLake - Microsoft\<Workspace>\<Lakehouse>.Lakehouse\Files\landing\<feed>` —
the first P3381 batch landed in `Files\p3381_sap` (no `landing`) and the notebook silently did nothing.

**Import vs Direct Lake:** default to **Import** — the reports keep their Power Query steps
and calculated columns, only the source changes. Choose **Direct Lake** only if the team
will move all Power Query / calculated-column logic into the notebook; that removes the
refresh step but the effort varies per report.

## Phase 2 — VBA runner (one .bas, per vba-project-structure)

Template: `references/templates/DailyRefresh.bas`. Blank Access DB, **no tables**.

**Entry points** — public functions returning Boolean: `RunDailyRefresh`,
`RunInventoryMonthEnd`, `RunKE24Backfill`, `RunForecastImport`, `RunProvisionImport`,
`RunSnapshotBackfill`. Occasional jobs: Access macro (Create > Macro > RunCode >
`RunProvisionImport()`). Daily: the `.vbs` launcher (Access.Application →
OpenCurrentDatabase → Run → Quit).

Checklist:
- [ ] **One SAP window.** First job opens ONE new window with `/o<tcode>` (poll `conn.Children.Count`); later jobs reuse it with `/n<tcode>`. `ResetSAP` closes leftover popups (`sendVKey 12`). At the end `/i` closes only the window the macro opened — **never the user's own window**.
- [ ] **No fixed pauses.** `WaitSAPIdle`: poll `session.Busy`, `Sleep 100` + `DoEvents`, midnight-safe (no `Timer` arithmetic for waits).
- [ ] **Run all SAP extracts back to back first**, then hand files over — SAP never waits on file work.
- [ ] **No parsing in VBA.** Wait until the file size is stable, `Fso.MoveFile` into the outbox. The filename carries the metadata the notebook reads: `<feed>_raw_[tag_]yyyymmdd_hhnnss_N.csv` (e.g. `ke24_raw_Current_009_2026_…`, `inv_month_raw_P008_2026_…`). Measured: VBA parsing a 76k-row MB52 file took 43 s and froze Access; raw hand-over < 1 s.
- [ ] **Background upload**, one log per file (concurrent copies cannot share a log):
  ```bat
  cmd /c robocopy "<outbox\feed>" "<landing\feed>" "<file>" /MOV /R:20 /W:3 /NP /NJH /NJS /NDL > "uploadlogs\<file>.log"
  ```
  launched hidden with `WScript.Shell.Run`. `FinishBatch` writes a generated `.cmd` that waits (ping loop, 10-min cap) until every listed file has left the outbox, then robocopies the batch file, appends "upload complete" to `Upload_log.txt`, and deletes itself. `RequeueLeftovers` at start re-sends outbox files left by an interrupted run.
- [ ] **Batch manifest**: one line per file `feed/file.csv|bytes`, written with FSO `CreateTextFile` (plain ASCII). ⚠️ ADODB.Stream UTF-8 added a BOM; the notebook read `\ufeffinv_daily_raw/...` as the folder name and waited forever.
- [ ] **Never touch the OneLake mount synchronously mid-run.** A `FileExists` on OneLake queued behind the MB52 upload and stalled the macro. Keep run state locally in `C:\Temp\SAPExports`.
- [ ] **KE24 month-end freeze**: local marker `ke24_last_close_month.txt` (yyyymm). First run of a new month re-extracts the previous period as `MonthEnd` and saves the marker on success. A fresh install **seeds** the marker to the current month so no unwanted close runs.
- [ ] **Excel-workbook imports** (forecast, provisions, snapshot backfill) stay in VBA and write pipe-delimited files. Provisions carry `Load_Mode` REPLACE/APPEND because the overlap check can't be done locally.
- [ ] **Logging**: `DailyRefresh_log.txt` with per-stage timings (`LogStep`); seconds per job in the summary MsgBox.
- [ ] **Source status file (`run_info`)** — key|value lines: per source `<src>_status` OK / FAILED / NODATA, `<src>_at`, `<src>_message`, plus `run_date`, windows, `feed_version` and what was asked of SAP (e.g. `mb51_mvts=101,102,601,602`). A failed extract does **not** stop the batch; MB51 "no documents" is a valid empty day (NODATA), not a failure.

Install gotchas:
- Delete the old module before File > Import (otherwise `DailyRefresh1` → "Ambiguous name")
- If pasting instead of importing, drop the `Attribute VB_Name` line
- Debug > Compile to find errors; click **Enable Content** on the yellow bar
- "Can't find the procedure" from the `.vbs` → the module wasn't re-imported/compiled, or the entry-point name in the `.vbs` doesn't match

### Phase 2b — Chaining a second feed in the same runner (optional, v2.3)

Pattern from P3381 (`RunDailyRefreshWithP3381` in the template):
- [ ] Refactor the original body into `DailyRefreshCore(summary, nOk, nFail, showDialog)`; `RunDailyRefresh` keeps its exact behaviour by calling it with the dialog on
- [ ] `WaitForDailyUpload`: poll until the local `outbox\_ready\<batch>.txt` is gone (robocopy `/MOV` moved it = it is in OneLake, so the first pipeline starts first); status-bar progress; cap ≈ **11 min** (just past the 10-min background-upload cap). Not confirmed → carry on and say so in the dialog
- [ ] Run the second feed, then **one combined MsgBox**: per-job OK/FAILED lines, upload confirmation, batch id, elapsed time; trimmed to ~1000 chars, full detail in the log
- [ ] Also give the second feed its own stand-alone entry point (`RunP3381Feed`)
- [ ] Desktop `.vbs`: only change `acc.Run "RunDailyRefresh"` to the new entry point; keep `Visible = True` so the end dialog shows; Access closes after OK

**Porting an Excel feed macro into Access:**
- [ ] Front-sheet settings → `P3_*`-style constants; scope lists → arrays returned by functions
- [ ] Replace Excel-only APIs: `Application.Wait` → Sleep/DoEvents `PauseSeconds`; `Application.StatusBar` → `SysCmd 4/5` (late-bound, Excel fallback); `ThisWorkbook.Name` → `CurrentProject.Name`; worksheet clipboard fallback → Win32 clipboard API / Forms DataObject
- [ ] Prefix every ported procedure (e.g. `P3381_`) to avoid name clashes
- [ ] Reuse the module's single SAP session (`/o` once, `/n` after) and its `EndSAP`
- [ ] Keep recorded SAP lines byte-identical except the flagged fixed values — **diff-check the `findById` lines** old vs new

## Phase 3 — Lakehouse & notebooks

**History load (one-off)** — template `nb_load_history.ipynb`:
- [ ] Convert Access text exports in Python to pipe-delimited `.csv.gz` with an explicit per-table spec (types `s`/`n`/`i`/`b`/`t`; dates d/m/yyyy → ISO; strip `£`)
- [ ] Notebook writes Delta tables and checks rows loaded against an `EXPECTED` dict (Bradford: all 18 tables matched exactly)
- [ ] It seeds `Files/state` flags and creates the landing folders
- Fabric **lowercases table names** on save (`tbl_DailySnapshot` → `tbl_dailysnapshot`); column names keep their case; spaces → underscores
- SQL analytics endpoint may show only `sys`/`queryinsights` right after a load → open the endpoint and press **Refresh**

**Daily ingest** — template `nb_daily_ingest.ipynb`:
- [ ] Feeds folder by folder in a **fixed order** (KE24 before FG stock — FG uses KE24 customers)
- [ ] Raw converters in Python (`sap_raw.py`): decode cp1252, honour a BOM if present; find the header row by marker words; map columns by header name with `abbreviated|full` alternatives (exact match, then ends-with); trim spaces only; numbers: drop thousands commas, trailing minus to front, blank/`-` → 0; SAP dates → ISO; MB52 material column taken from the header so unit-total lines are skipped
- [ ] Business rules as pure functions (`rules.py`), **verified against history before go-live** (Bradford: KE24 customer/finance mapping 12,930/12,930 rows, FG 70/70, forecast 135/135)
- [ ] **Idempotent writes**: Delta `replaceWhere` per slice (snapshot date / period / run type); MERGE for master data; IDs = max + row_number
- [ ] `align()` projects onto the target schema: text coalesced to `""` (Access blank ≠ null — Power Query `Text.Contains` broke on nulls), whole numbers `bround` to bigint, Yes/No → boolean
- [ ] Folders: `landing` / `_claimed` / `processed` (raw files kept → reload any day by moving back to landing) / `quarantine`; `tbl_IngestLog` replaces the Access logs
- [ ] **Duplicate-trigger safety**: claim each batch file by moving it to `_claimed` (whoever moves it owns it); one SHARED 10-minute upload deadline across all waiting batches; skip files already processed or quarantined; strip a BOM from manifests defensively
- [ ] **Sync the SQL endpoint after loading** — otherwise the model refresh reads the previous table version (seen: report card stuck on old "Last Extract"):
  ```python
  # sempy FabricRestClient
  GET  v1/workspaces/{ws}/lakehouses/{lh}            -> sqlEndpointProperties.id
  POST v1/workspaces/{ws}/sqlEndpoints/{id}/refreshMetadata   # poll the Location header
  # fallback: time.sleep(60)
  ```
- [ ] Finish with `mssparkutils.notebook.exit("LOADED" | "NOTHING_TO_LOAD")`; raise only **after** logging if any file failed

**Validation method that worked:** port the legacy VBA logic to Python, compare row-for-row on
real raw files, then compare against the Access history.

**Re-importing a notebook** gives it a new item ID; the pipeline still points at the old one →
"User is not authorized to access the notebook … 401". Fix: Notebook activity > Settings >
Refresh > reselect the notebook (keep the activity name — expressions use it), and reattach
the lakehouse to the notebook. Rename or delete the old notebook **before** importing
(otherwise Fabric creates "<name> 1" and the pipeline keeps running the old one).

**Print a `NOTEBOOK_VERSION` line** at the top of the run cell and return it in the exit
JSON. Twice on P3381 the user was running a stale notebook after a re-import; the version
line ends the guesswork. When a user reports an error, **first check which version actually
ran** (version line / traceback line shape) before changing code.

### Phase 3b — Python (non-Spark) notebook variant (small files)

For small daily files use a Fabric **Python** notebook (pandas + `deltalake`) — it starts in
seconds instead of a Spark session. Template: `references/templates/fabric_io_python_delta.py`.
- [ ] **Never write Delta through the `/lakehouse/default` FUSE mount.** `write_deltalake` fails with `OSError: Generic LocalFileSystem error: Unable to rename file: No such file or directory (os error 2)` / `Operation not permitted (os error 1)` — Delta commits rename files. Write over **abfss**:
  ```python
  ctx = notebookutils.runtime.context
  uri = f"abfss://{ctx['currentWorkspaceId']}@onelake.dfs.fabric.microsoft.com/{ctx['defaultLakehouseId']}/Tables"
  if os.path.isdir("/lakehouse/default/Tables/dbo"): uri += "/dbo"     # schema-enabled lakehouse
  write_deltalake(f"{uri}/{name}", data, mode="overwrite", schema_mode="overwrite",
                  storage_options={"bearer_token": notebookutils.credentials.getToken("storage"),
                                   "use_fabric_endpoint": "true"})
  ```
  Reading / moving plain files under `/lakehouse/default/Files` with os/shutil is fine.
- [ ] **Schema-enabled lakehouses** keep tables under `Tables/dbo` → append `/dbo`; Power BI partitions then use `Schema="dbo"`
- [ ] Write with a **fixed Arrow schema per table** (a `TABLES` contract dict, shared with the PBIP generator) so an empty batch never changes a column type
- [ ] `read_table` returns None when the table doesn't exist yet — match case-insensitively: "not a delta table", "no files in log segment", "not found", "does not exist"
- [ ] **Concurrent commits** — `CommitFailedError: a concurrent transaction deleted the same data your transaction deletes` when two runs overlap. Retry overwrite writes (idempotent) up to ~6 times with back-off + jitter; re-raise anything else. Root fix is the trigger filter + concurrency 1 (Phase 5)
- [ ] Pandas gotchas: an all-None timestamp column becomes NaT (test with `pd.isna`, not `is None`); skip `pd.concat` when nothing older is kept (empty-frame FutureWarning); store UK wall-clock times **labelled UTC** so the SQL endpoint / Power BI don't shift them by the BST offset

**`.done` batch handling (defensive notebook):**
- [ ] Process a batch only when every listed file exists; missing files → wait (30-min grace) then move to quarantine with `error.txt`; processed batches → `Files/processed/<feed>/<stamp>`
- [ ] If the `.done` disappeared (another run took it) → skip with a note, don't quarantine. File moves tolerate FileNotFound when the source is already gone, but retry if it still exists (storage briefly busy)
- [ ] Append-type log tables de-duplicate on (BatchId, Source) so a re-run never doubles a batch
- [ ] Report `.done` files found **elsewhere** under `Files` (`found_elsewhere` in the summary) with the exact fix, instead of silently doing nothing

**Source status — blank, never zero:**
- [ ] Read the macro's `run_info`; a source that FAILED shows as *not refreshed* (blank), never as zero. NODATA is a valid empty day
- [ ] Check the recorded parameters (`feed_version`, `mb51_mvts` …) so a batch from an older macro version shows "not refreshed" instead of a false zero
- [ ] Write a `source_quality` table (Source, RefreshedAt, IsReady, Detail) — it drives readiness measures and the header status pills in the report

## Phase 4 — Power BI semantic models

**Edit models as PBIP/TMDL text** (one pass, no clicking through Power Query):
- [ ] In each partition replace the Access source with the lakehouse; Schema `""` → `"dbo"`; item names lowercase:
  ```m
  // before
  Source = Access.Database(File.Contents("…\Inventory.accdb"), [CreateNavigationProperties=true]),
  tbl = Source{[Schema="",Item="tbl_DailySnapshot"]}[Data]
  // after
  Source = Sql.Database(LakehouseServer, "<Lakehouse>"),
  tbl = Source{[Schema="dbo",Item="tbl_dailysnapshot"]}[Data]
  ```
- [ ] Add `definition/expressions.tmdl`:
  ```
  expression LakehouseServer = "<endpoint>.datawarehouse.fabric.microsoft.com" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]
  ```
- [ ] Add `Table.RenameColumns` steps to restore spaced names (e.g. `JLR_Impact` → `"JLR Impact"`)
- [ ] Recreate any Access archive window as a Power Query filter (e.g. last 30 days + Mondays) so reports show the same range
- [ ] Leave DAX, calculated columns and relationships untouched; don't ship `.pbi/cache.abf`

**In Power BI Desktop:**
- [ ] SQL connection string: lakehouse → SQL analytics endpoint → Settings (gear). Paste into Transform data > Edit parameters > `LakehouseServer`, Apply changes. Stale navigator → File > Options > Data Load > Clear cache. **Do NOT add tables via OneLake catalog.**
- [ ] Rename a PBIP only via File > Save as (the .pbip → .Report → definition.pbir → .SemanticModel links break if renamed in Explorer)
- [ ] Work in PBIP stored in SharePoint/OneDrive with a **short path** (deep visual folders hit the Windows path limit); keep .pbix only as snapshots
- [ ] Publishing under a new name creates **new** items — the pipeline must select the newly published models. The activity label means nothing; check the dataset ID (in the model settings URL after `/datasets/`)

### Phase 4b — Generating a new PBIP from code (new dashboards)

For a new report (P3381) rather than a migration, generate the whole Power BI project from
**one Python generator**:
- [ ] TMDL: model, `expressions.tmdl` with `SqlEndpoint` / `LakehouseName` parameters, partitions `Sql.Database(SqlEndpoint, LakehouseName){[Schema="dbo",Item="<table>"]}[Data]`, relationships, measures — column types from the same `TABLES` contract as the notebook
- [ ] PBIR: pages and visuals as JSON
- [ ] Stable **uuid5 lineage tags** → clean diffs and repeatable rebuilds
- [ ] Before handing over: parse every JSON file and lint measure/column references (check_dax-style)
- [ ] Certified visuals that worked: **HTML Content** (role `content`) for HTML/SVG cards; **Deneb** (Vega-Lite, role `dataset`) for lane / stacked charts
- [ ] After any model/report rebuild the user must: re-enter the `SqlEndpoint` parameter, refresh, publish **over** the existing report. New lakehouse tables must exist (notebook run once) before that refresh

**Design lessons from user feedback:**
- Don't cram secondary topics onto the overview — shipments and output get their own pages
- Text ≥ 13 px, bold for key numbers/labels (cards: 40 px stock, 20 px part numbers)
- Horizon selectors as **button tiles** (slicer mode Basic, horizontal, single-select), not dropdowns
- One-line title `<Programme> <Topic> · Daily Review` with date/time; no eyebrow or subtitle rows

### OAuth 2.0 — there are TWO separate connections

**(1) Pipeline → semantic model** (lets the pipeline start a refresh)
1. In the pipeline, select a **Semantic model refresh** activity > **Settings** > **Connection** > **New**.
2. Type **Power BI Semantic Model**, authentication **OAuth 2.0**, **Sign in**.
3. Name it e.g. `PBI semantic models – <user>`.
4. Pick **Workspace** + **Semantic model** for this activity.
5. On every other refresh activity, reuse the same connection; pick its own model.

**(2) Semantic model → lakehouse** (lets the model read the data — *this is the one that fixes the 3101 error*)
1. Workspace > the semantic model (type **Semantic model**, not Report) > **…** > **Settings** (or gear > Power BI settings > Semantic models).
2. Expand **Gateway and cloud connections**.
3. If **"Use an On-premises or VNet data gateway"** is On (leftover personal gateway from the Access era) → switch **Off** > **Apply**.
   If it is greyed out, or Cloud connections shows "No cloud connections" → republish from Desktop so the model only has the lakehouse source, then come back.
4. Under **Cloud connections**, the SQL Server row (`<endpoint>; <Lakehouse>`) > **Maps to** > **Create a connection**:
   - Connection name: e.g. `<Lakehouse> – SQL`
   - Connection type: **SQL Server**
   - Authentication method: **OAuth 2.0** > **Edit credentials** > sign in
   - Privacy level: **Organizational**
   - **Create** → back on the model, **Apply**
5. Other models: same row > Maps to > pick the **same** connection > Apply.
6. Test: **…** > **Refresh now**, then **Refresh history**. No gateway needed (cloud to cloud).
7. Turn **off** each model's scheduled refresh (the pipeline refreshes them now).

**Symptom map**
- Error 3101 `ModelRefresh_ShortMessage_ProcessingError` / `Premium_ASWL_Error` "uses a default data connection without explicit connection credentials" → connection (2) missing (Maps to shows "Default: Single Sign-On") **or** the pipeline points at an old/different model (e.g. a leftover model reading OneLake directly).
- `RefreshInProgressException` → overlapping refreshes: pipeline concurrency, a model schedule still on, duplicate refresh boxes, or a manual Refresh now.

**Long term:** ask IT for a **service principal** to own both connections, so refreshes don't depend on one person's login.

## Phase 5 — Pipeline

Data pipeline `pl_daily_refresh`:
- [ ] **Notebook** activity "Daily Ingest" → **If condition**, connected with the blue **On completion** arrow (not On success — a partial load still refreshes)
- [ ] If condition expression:
  ```
  @not(equals(coalesce(activity('Daily Ingest').output?.result?.exitValue, 'LOADED'), 'NOTHING_TO_LOAD'))
  ```
- [ ] **True** branch holds the Semantic model refresh activities, **Wait on completion** ticked
- [ ] Each refresh activity: General > Retry **2**, interval **120 s**
- [ ] Canvas (blank area) > Settings > **Concurrency = 1**
- [ ] Validate > Save > Run

**Trigger:** Trigger > Add **OneLake events**; source = the lakehouse; subject **begins with**
`Files/landing/_ready`; event type **File created** only. Expect double triggers (OneLake File
Explorer create + write) — handled by concurrency 1 + the claim pattern + the NOTHING_TO_LOAD
skip. Enable the **starter pool**: small files are dominated by Spark start-up (see
fabric-event-ingestion).

**With the `.done` sentinel:** File created fires for **every** file (≈9 per P3381 batch) →
several parallel notebook runs → `CommitFailedError`. Filter **Subject → ends with `.done`**
(or begins with `…/_ready` for the manifest pattern), keep pipeline **Concurrency = 1**, and
keep the commit retry in the notebook as the last line of defence. A second feed gets its
own lakehouse, pipeline and trigger (P3381: `lh_p3381_daily`, Notebook → semantic model refresh).

## Phase 6 — Cut-over

- [ ] Run old and new side by side for 2–3 mornings; compare totals per report
- [ ] Keep the original .pbix files as fallback
- [ ] Repoint users to the new reports; then delete leftovers (old models, old Access modules, old schedules, personal gateway mappings)

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Navigator / endpoint shows only `sys` / `queryinsights` | SQL endpoint not refreshed after load | Open the SQL analytics endpoint > Refresh |
| "The key didn't match any rows in the table" | Table names now lowercase, or stale Desktop cache | Lowercase `Item=` names; File > Options > Data Load > Clear cache |
| Pipeline: "User is not authorized to access the notebook … 401" | Notebook re-imported → new item ID | Notebook activity > Settings > Refresh > reselect; reattach lakehouse |
| Error 3101 "default data connection without explicit connection credentials" | Model → lakehouse connection (2) missing, or pipeline points at an old model | Phase 4 OAuth step (2); check dataset IDs in the refresh activities |
| `RefreshInProgressException` | Overlapping refreshes | Concurrency 1; model schedules off; no duplicate refresh boxes; no manual Refresh now during a run |
| Report card shows the old "Last Extract" | SQL endpoint not synced; or raw files not loaded because the old notebook is still attached; or BOM in manifest | `refreshMetadata` call (Phase 3); reselect the current notebook; write manifest with FSO plain ASCII |
| Notebook log: `waiting for upload of ['\ufeff…']` | BOM in the batch manifest | FSO `CreateTextFile`, not ADODB.Stream UTF-8; notebook strips BOM defensively |
| Access freezes after the last SAP export | VBA parsing the export | Switch to raw hand-over (Phase 2) |
| Long pause between two SAP jobs | Synchronous OneLake access mid-run | Keep run state local; only robocopy touches the mount |
| KE24 month-end re-ran unexpectedly | Marker file missing | Seed `ke24_last_close_month.txt` to the current month on install |
| "Ambiguous name detected" after import | Old module still present (`DailyRefresh1`) | Delete old module, then File > Import |
| `write_deltalake`: "Unable to rename file" (os error 2 / os error 1) | Writing Delta through the `/lakehouse/default` FUSE mount | Write over abfss with a storage token (Phase 3b) |
| Notebook summary empty / "No *_batch_*.done in landing" | Batch landed in another folder (e.g. `Files\<feed>` without `landing`) | Fix the macro's landing path; notebook reports `found_elsewhere` (Phase 3b) |
| `CommitFailedError … concurrent transaction` in the pipeline | Trigger fires once per file → overlapping runs | Trigger filter ends with `.done`, concurrency 1, commit retry (Phase 5) |
| Notebook keeps showing an old error after a fix | Stale notebook still running (re-import made "name 1") | Check the printed `NOTEBOOK_VERSION`; rename/delete old, reattach lakehouse, reselect in pipeline |
| "COOIS: no Planned order column" while planned orders exist | Classifying by column instead of order number | Classify by order number: `96*` released, `2*` planned (Phase 0 data rules) |
| "Can't find the procedure" from the `.vbs` | Module not re-imported/compiled, or entry-point name mismatch | Re-import the .bas, Debug > Compile, check the `acc.Run` name |
| Dashboard shows 0 for a source that failed | Missing status handling | `run_info` statuses + `source_quality` table → blank, never zero (Phase 3b) |

## Output

When applying this playbook, produce: the Phase 0 request list (one message), then the
deliverables in efficient-path order — converted history files + `nb_load_history`,
`nb_daily_ingest`, edited `.SemanticModel` folders zipped + a plain-language instructions
file (or a generated PBIP for a new dashboard), pipeline/trigger and OAuth click-steps, the
single `.bas` + `.vbs` launcher, and the full OneLake landing path. Each
deliverable comes with a short "how to install" list and a check the user can run (row
counts, totals, a test refresh).

## Guardrails

- Keep recorded SAP steps unchanged (sap-script-discipline) — only filenames and named parameters change
- Never close the user's own SAP window; only the one the macro opened
- Never claim a business rule is correct until it matches history row-for-row; report mismatches, never fabricate counts
- Don't delete Access files, old reports or old schedules until the side-by-side run is signed off
- Never store passwords or secrets in the macro, notebook or models; OAuth sign-in only, service principal long term
- Swap all Bradford-specific (and `P3_*` / P3381) names in the templates before giving them to another site
- A source that failed shows as blank / not refreshed — never as zero
- When a user reports a notebook error, confirm which notebook version ran before changing code
- Ask early whether a new lakehouse feed stays standalone from existing Excel tools
